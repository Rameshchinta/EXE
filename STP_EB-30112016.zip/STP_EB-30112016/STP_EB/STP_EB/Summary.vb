﻿Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel

Public Class Summary

    Public Sub Generate_Summary(Summary_File As String)

        Dim Total_Claims As Integer
        Dim Pass_Count As Integer
        Dim Except_Count As Integer

        Dim SL_NO As String
        Dim PHNO As String
        Dim CERTNO As String
        Dim DEPNO As String
        Dim Dateofcon As String
        Dim dateofrep As String
        Dim CONSLT As String
        Dim BILLAMT As String
        Dim Diag_Descp As String
        Dim diag_Others As String
        Dim Diag_Code As String
        Dim Doctor_Name As String
        Dim Doctor_Code As String
        Dim claim_type_csv As String
        Dim Claim_Num As String
        Dim Currency_Converted As String
        Dim Remark_Code As String
        Dim claim_status As String
        Dim error_Descp As String
        Dim username As String
        Dim process_Date As String
        Dim patient_name As String
        Dim patient_name_eb As String
        Dim member_num As String
        Dim C_count As Integer = 0
        Dim remark4 As String
        Dim remark3 As String
        Dim remark2 As String
        Dim remark1 As String
        Dim Policy_Currency As String
        Dim Indicator_ctc_flag As String

        Dim rows_Count As Integer

        Dim Index_Array As New ArrayList

        Dim con2 As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Summary_File & ";Extended Properties=Excel 12.0 Macro")
        con2.Open()
        Dim ad1 As New OleDbDataAdapter("Select * From [Exceptions$]", con2)
        Dim ds1 As New DataSet
        ad1.Fill(ds1)

        con2.Close()
        con2 = Nothing

        'SL_NO = ds1.Tables(0).Rows.Count + 1

        Dim con1 As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Summary_File & ";Extended Properties=Excel 12.0 Macro")
        con1.Open()
        Dim ad As New OleDbDataAdapter("Select [SL_NO],[USERNAME],[CLAIM_TYPE],[PROCESSING DATE],[CLAIM NUMBER],[POLICY NUMBER],[MEMBER NUMBER],[DEPENDENT NO],[PATIENT NAME],[PATIENT NAME EB],[MEMBERSHIP NUMBER],[DATE OF CONSULTATION],[CONSULTATION TYPE],[DATE OF RECEIPT],[DIAGNOSIS TEXT],[DIAGNOSIS (OTHERS)],[DIAGNOSIS CODE],[DOCTOR NAME],[DOCTOR CODE],[CURRENCY],[CURRENCY CONVERTED (Y/N)],[AMOUNT TO BE CLAIMED],[REMARK CODE 1],[REMARK CODE 2],[REMARK CODE 3],[REMARK CODE 4],[REMARK CODE],[CLAIM STATUS],[ERROR DESCRIPTION],[INDICATOR OF CTC] From [Pass$]", con1)
        Dim ds As New DataSet
        ad.Fill(ds)

        Total_Claims = ds.Tables(0).Rows.Count

        For i = 0 To ds.Tables(0).Rows.Count - 1

            SL_NO = GetStringValue(ds.Tables(0).Rows(i).ItemArray(0))
            username = GetStringValue(ds.Tables(0).Rows(i).ItemArray(1))
            claim_type_csv = GetStringValue(ds.Tables(0).Rows(i).ItemArray(2))
            process_Date = GetStringValue(ds.Tables(0).Rows(i).ItemArray(3))
            Claim_Num = GetStringValue(ds.Tables(0).Rows(i).ItemArray(4))
            PHNO = GetStringValue(ds.Tables(0).Rows(i).ItemArray(5))
            CERTNO = GetStringValue(ds.Tables(0).Rows(i).ItemArray(6))
            DEPNO = GetStringValue(ds.Tables(0).Rows(i).ItemArray(7))
            patient_name = GetStringValue(ds.Tables(0).Rows(i).ItemArray(8))
            patient_name_eb = GetStringValue(ds.Tables(0).Rows(i).ItemArray(9))
            member_num = GetStringValue(ds.Tables(0).Rows(i).ItemArray(10))
            Dateofcon = GetStringValue(ds.Tables(0).Rows(i).ItemArray(11))
            CONSLT = GetStringValue(ds.Tables(0).Rows(i).ItemArray(12))
            dateofrep = GetStringValue(ds.Tables(0).Rows(i).ItemArray(13))
            Diag_Descp = GetStringValue(ds.Tables(0).Rows(i).ItemArray(14))
            diag_Others = GetStringValue(ds.Tables(0).Rows(i).ItemArray(15))
            Diag_Code = GetStringValue(ds.Tables(0).Rows(i).ItemArray(16))
            Doctor_Name = GetStringValue(ds.Tables(0).Rows(i).ItemArray(17))
            Doctor_Code = GetStringValue(ds.Tables(0).Rows(i).ItemArray(18))
            Policy_Currency = GetStringValue(ds.Tables(0).Rows(i).ItemArray(19))
            Currency_Converted = GetStringValue(ds.Tables(0).Rows(i).ItemArray(20))
            BILLAMT = GetStringValue(ds.Tables(0).Rows(i).ItemArray(21))
            remark1 = GetStringValue(ds.Tables(0).Rows(i).ItemArray(22))
            remark2 = GetStringValue(ds.Tables(0).Rows(i).ItemArray(23))
            remark3 = GetStringValue(ds.Tables(0).Rows(i).ItemArray(24))
            remark4 = GetStringValue(ds.Tables(0).Rows(i).ItemArray(25))
            Remark_Code = GetStringValue(ds.Tables(0).Rows(i).ItemArray(26))
            claim_status = GetStringValue(ds.Tables(0).Rows(i).ItemArray(27))
            error_Descp = GetStringValue(ds.Tables(0).Rows(i).ItemArray(28))
            Indicator_ctc_flag = GetStringValue(ds.Tables(0).Rows(i).ItemArray(29))

            If claim_status = "C" Or claim_status = "" Or claim_status = Nothing Then
                Dim cmd As New OleDbCommand("Insert into [Exceptions$] Values('" & SL_NO & "','" & Replace(username, "'", "''") & "','" & claim_type_csv & "','" & process_Date & "','" & Claim_Num & "','" & PHNO & "','" & CERTNO & "','" & DEPNO & "','" & Replace(patient_name, "'", "''") & "','" & Replace(patient_name_eb, "'", "''") & "','" & member_num & "','" & Dateofcon & "','" & Replace(CONSLT, "'", "''") & "','" & dateofrep & "','" & Replace(Diag_Descp, "'", "''") & "','" & Replace(diag_Others, "'", "''") & "','" & Diag_Code & "','" & Replace(Doctor_Name, "'", "''") & "','" & Doctor_Code & "','" & Policy_Currency & "','" & Currency_Converted & "','" & BILLAMT & "','" & remark1 & "','" & remark2 & "','" & remark3 & "','" & remark4 & "','" & Indicator_ctc_flag & "','" & Remark_Code & "','" & claim_status & "','" & error_Descp & "')", con1)
                cmd.ExecuteNonQuery()
                cmd = Nothing
                C_count = C_count + 1
            End If

            'SL_NO = SL_NO + 1
        Next

        con1.Close()
        con1 = Nothing

        Dim xlapp As New Excel.Application
        Dim xlwb As Excel.Workbook = xlapp.Workbooks.Open(Summary_File) 'Excel workbook to store the PDF table
        Dim xlsheet As Excel.Worksheet
        Dim rang As Excel.Range

        xlapp.Visible = False

        xlsheet = xlwb.Worksheets("Pass")

        rows_Count = xlsheet.UsedRange.Rows.Count

        'Delete rows with claim status C or blank or nothing
        If Not C_count = 0 Then
            For i = 2 To rows_Count
                If xlsheet.Range("AE" & i).Value = "C" Or xlsheet.Range("AE" & i).Value = "" Or xlsheet.Range("AE" & i).Value = Nothing Then
                    xlsheet.Range("AE" & i).EntireRow.Delete()
                    i = i - 1
                    C_count = C_count - 1

                    If C_count = 0 Then
                        Exit For
                    End If
                End If
            Next
        End If

        Pass_Count = xlsheet.UsedRange.Rows.Count - 1

        xlsheet = Nothing
        xlsheet = xlwb.Worksheets("Exceptions")

        Except_Count = xlsheet.UsedRange.Rows.Count - 1

        xlsheet = Nothing
        xlsheet = xlwb.Worksheets("Summary")

        xlsheet.Range("C5").Value = Pass_Count + Except_Count
        xlsheet.Range("C7").Value = Total_Claims
        xlsheet.Range("C8").Value = Pass_Count
        xlsheet.Range("C9").Value = Except_Count
        xlsheet.Range("C11").Value = "0"



        xlwb.Save()
        xlwb.Close()
        xlapp.Quit()
        xlwb = Nothing
        xlapp = Nothing

        'matching logic

    End Sub

    Function GetStringValue(ByVal value As Object) As String
        If value Is DBNull.Value Then
            GetStringValue = Nothing
        Else
            GetStringValue = value
        End If
    End Function

End Class
