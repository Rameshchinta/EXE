﻿Imports System.IO
Imports MetroFramework
Imports System.Xml

Public Class Folder_Struct

    Public Shared_Path As String
    Public Remark_Config As String

    Public Csv_Path As String
    Public Config_Path As String
    Public Summary_File As String
    Public claimproc As Claim_Processing
    Public Validation As Validations
    Public Summary_Gene As Summary

    Public Diag_Code_File As String
    Public Doctor_Code_File As String
    Public Shared_Config_path As String
    Public Local_Config_path As String
    Public Local_Config_File As String
    Public Shared_OpFile_path As String
    Public Shared_BkupFile_path As String
    Public Shared_Rename_path As String
    Public Local_Folder_path As String
    Public Shared_Proc_Dir As String
    Public Shared_Compl_Dir As String
    Public Rename_File As String
    Public CSV_Filename As String
    Public Summary_Filename As String

    Public Proc_CSV As String
    Public Proc_Summary As String

    Public Sub Check_Folder_Structure()

        Shared_drive()
        Check_Access()
        Check_Config_Folder()
        Check_For_Local()
        Copy_To_Local()

    End Sub

    Private Function Check_Access()

        Dim access As Boolean = False

        Do
            If Directory.Exists(Shared_Path) Then
                access = True
                Exit Do
            Else
                MetroMessageBox.Show(Form1, "There is no access to Shared Drive" & vbCrLf & "Please connect to Shared Drive and try again later.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                access = False
                Application.Exit()
                End
            End If
        Loop Until access = True

    End Function

    '*******************************************************************************************
    'Function Name  - Check_For_Local()
    'Parameters     - 
    'Description    - Function to check if the files and folders are present within shared Drive
    'Return         - Nothing
    '*******************************************************************************************

    Private Function Check_For_Local()

        Dim csvfile As String
        Dim processed_csv As String
        Dim processed_xlsx As String
        Dim csvfilepath As String
        Dim summaryfilepath As String

        Local_Folder_path = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\EB-Bot"

        If Directory.Exists(Local_Folder_path) Then

            Diag_Code_File = Shared_Path & "\Configurable_Files\DataCapture_Interface\Diagnosis_Code.csv"
            Doctor_Code_File = Shared_Path & "\Configurable_Files\DataCapture_Interface\Doctor_Codes.csv"
            Shared_Config_path = Shared_Path & "\Configurable_Files\EB-Bot"
            Local_Config_path   = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\EB-Bot\Configurable_Files"
            Local_Config_File = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\EB-Bot\Configurable_Files\Config file - EB.xlsm"
            Shared_OpFile_path = Shared_Path & "\Output_Files"
            Shared_BkupFile_path = Shared_Path & "\Output_Files\Backup_Files"
            Shared_Proc_Dir = Shared_Path & "\Output_Files\Processing"
            Shared_Compl_Dir = Shared_Path & "\Output_Files\Summary"


            My.Computer.FileSystem.CopyDirectory(Shared_Config_path, Local_Config_path, True)
            My.Computer.FileSystem.CopyFile(Diag_Code_File, Local_Config_path & "\Diagnosis_Code.csv", True)
            My.Computer.FileSystem.CopyFile(Doctor_Code_File, Local_Config_path & "\Doctor_Codes.csv", True)

            My.Computer.FileSystem.WriteAllText(Local_Config_path & "\schema.ini", My.Resources.schema, False)






            Dim dir As DirectoryInfo = New DirectoryInfo(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\EB-Bot")
            Dim xlsx_files As FileInfo() = dir.GetFiles("*.xlsx")

            If Not xlsx_files.Length = 0 Then
                For Each xlsxfile As FileInfo In xlsx_files
                    If Right(xlsxfile.Name, 6) = "1.xlsx" Then

                        claimproc = New Claim_Processing
                        claimproc.RLS_Extraction(Local_Folder_path & "\Configurable_Files\Config file - EB.xlsm", xlsxfile.FullName)

                        Summary_Gene = New Summary
                        Summary_Gene.Generate_Summary(xlsxfile.FullName)

                        If Not Directory.Exists(Local_Folder_path & "\Backup_Files") Then
                            Directory.CreateDirectory(Local_Folder_path & "\Backup_Files")
                        End If

                        If Not Directory.Exists(Shared_OpFile_path & "\Summary_Files") Then
                            Directory.CreateDirectory(Shared_OpFile_path & "\Summary_Files")
                        End If

                        processed_xlsx = Left(xlsxfile.Name, Strings.Len(xlsxfile.Name) - 6) & "2.xlsx"

                        csvfile = Left(xlsxfile.Name, Strings.Len(xlsxfile.Name) - 5) & ".txt"
                        csvfile = Replace(csvfile, "Summaryfile", "Claimfile")

                        csvfilepath = Local_Folder_path & "\" & csvfile
                        summaryfilepath = xlsxfile.DirectoryName

                        If File.Exists(Local_Folder_path & "\" & csvfile) Then
                            processed_csv = Left(csvfile, Strings.Len(csvfile) - 5) & "2.txt"
                            My.Computer.FileSystem.MoveFile(csvfilepath, Local_Folder_path & "\Backup_Files\" & processed_csv)
                        End If

                        Proc_Summary = Left(xlsxfile.Name, Strings.Len(xlsxfile.Name) - 6) & "2.xlsx"

                        My.Computer.FileSystem.MoveFile(summaryfilepath & "\" & xlsxfile.Name, Local_Folder_path & "\Backup_Files\" & Proc_Summary)

                        My.Computer.FileSystem.CopyFile(Local_Folder_path & "\Backup_Files\" & Proc_Summary, Shared_Path & "\Output_Files\Summary_Files\" & Proc_Summary)

                        If File.Exists(Shared_Proc_Dir & "\" & csvfile) Then
                            My.Computer.FileSystem.DeleteFile(Shared_Proc_Dir & "\" & csvfile)
                        End If
                    End If
                Next
            End If
        End If

    End Function

    '*******************************************************************************************
    'Function Name  - Check_Config_Folder()
    'Parameters     - 
    'Description    - Function to check if the files and folders are present within shared Drive
    'Return         - Nothing
    '*******************************************************************************************

    Private Function Check_Config_Folder()

        If Not Directory.Exists(Shared_Path & "\Configurable_Files") Then
            MetroMessageBox.Show(Form1, "Input File (Configurable Files) Folder does not exists", "Configurable File Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Application.Exit()
            End
        ElseIf Not Directory.Exists(Shared_Path & "\Configurable_Files\EB-Bot") Then
            MetroMessageBox.Show(Form1, "EB Configurable file folder does not exists", "Configurable File Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Application.Exit()
            End
        ElseIf Not File.Exists(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\Username and Password - HCP and EB.xlsx") Then
            MetroMessageBox.Show(Form1, "EB Username and Password File does not exists", "Configurable File Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Application.Exit()
            End
        ElseIf Not File.Exists(Shared_Path & "\Configurable_Files\EB-Bot\Config file - EB.xlsm") Then
            MetroMessageBox.Show(Form1, "EB Configuration file does not exists", "Configurable File Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Application.Exit()
            End
        ElseIf Not File.Exists(My.Computer.FileSystem.SpecialDirectories.Desktop & "\HKAS02.ws") Then
            MetroMessageBox.Show(Form1, "Please place the EB icon(HKAS02.ws) on the Desktop and try again later", "RLS Icon Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Application.Exit()
            End
        End If

    End Function

    '*******************************************************************************************
    'Function Name  - Copy_To_Local()
    'Parameters     - 
    'Description    - Function to copy files to local Directory
    'Return         - Local Path
    '*******************************************************************************************

    Private Function Copy_To_Local()

        Local_Folder_path = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\EB-Bot"

        If Not Directory.Exists(Local_Folder_path) Then
            Directory.CreateDirectory(Local_Folder_path)
        End If

        Diag_Code_File = Shared_Path & "\Configurable_Files\DataCapture_Interface\Diagnosis_Code.csv"
        Doctor_Code_File = Shared_Path & "\Configurable_Files\DataCapture_Interface\Doctor_Codes.csv"
        Shared_Config_path = Shared_Path & "\Configurable_Files\EB-Bot"
        Local_Config_path = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\EB-Bot\Configurable_Files"
        Local_Config_File = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\EB-Bot\Configurable_Files\Config file - EB.xlsm"
        Shared_OpFile_path = Shared_Path & "\Output_Files"
        Shared_BkupFile_path = Shared_Path & "\Output_Files\Backup_Files"
        Shared_Proc_Dir = Shared_Path & "\Output_Files\Processing"
        Shared_Compl_Dir = Shared_Path & "\Output_Files\Summary"

        My.Computer.FileSystem.CopyDirectory(Shared_Config_path, Local_Config_path, True)
        My.Computer.FileSystem.CopyFile(Diag_Code_File, Local_Config_path & "\Diagnosis_Code.csv", True)
        My.Computer.FileSystem.CopyFile(Doctor_Code_File, Local_Config_path & "\Doctor_Codes.csv", True)


        My.Computer.FileSystem.WriteAllText(Local_Config_path & "\schema.ini", My.Resources.schema, False)


        Dim di As DirectoryInfo = New DirectoryInfo(Shared_OpFile_path)
        Dim csv_files As FileInfo() = di.GetFiles("*.txt")

        If csv_files.Length = 0 Then
            MetroMessageBox.Show(Form1, "No CSV claim files present For processsing", "Claim Files", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            For Each File_s As FileInfo In csv_files
                If File.Exists(File_s.FullName) Then
                    If Right(File_s.Name, 5) = "0.txt" Then
                        If Not Directory.Exists(Shared_BkupFile_path) Then
                            Directory.CreateDirectory(Shared_BkupFile_path)
                        End If

                        If Not Directory.Exists(Shared_Proc_Dir) Then
                            Directory.CreateDirectory(Shared_Proc_Dir)
                        End If

                        My.Computer.FileSystem.MoveFile(File_s.FullName, Shared_BkupFile_path & "\" & File_s.Name)

                        Rename_File = Left(File_s.Name, Strings.Len(File_s.Name) - 5) & "1.txt"

                        My.Computer.FileSystem.CopyFile(Shared_BkupFile_path & "\" & File_s.Name, Shared_Proc_Dir & "\" & Rename_File)

                        My.Computer.FileSystem.CopyFile(Shared_Proc_Dir & "\" & Rename_File, Local_Folder_path & "\" & Rename_File)

                        Summary_File = Local_Folder_path & "\" & Rename_File.Replace("Claimfile", "Summaryfile")
                        Summary_File = Left(Summary_File, Len(Summary_File) - 3) & "xlsx"

                        CSV_Filename = Path.GetFileName(Shared_Proc_Dir & "\" & Rename_File)
                        Summary_Filename = Path.GetFileName(Summary_File)

                        Csv_Path = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\EB-Bot\" & Rename_File

                        Validation = New Validations
                        Validation.Main_Validation(Csv_Path, Local_Config_File, Summary_File, Remark_Config)

                        claimproc = New Claim_Processing
                        claimproc.RLS_Extraction(Local_Config_File, Summary_File)

                        Summary_Gene = New Summary
                        Summary_Gene.Generate_Summary(Summary_File)

                        Proc_CSV = Left(CSV_Filename, Strings.Len(CSV_Filename) - 5) & "2.txt"

                        Proc_Summary = Left(Summary_Filename, Strings.Len(Summary_Filename) - 6) & "2.xlsx"

                        If Not Directory.Exists(Local_Folder_path & "\Backup_Files") Then
                            Directory.CreateDirectory(Local_Folder_path & "\Backup_Files")
                        End If

                        My.Computer.FileSystem.MoveFile(Csv_Path, Local_Folder_path & "\Backup_Files\" & Proc_CSV)
                        My.Computer.FileSystem.MoveFile(Summary_File, Local_Folder_path & "\Backup_Files\" & Proc_Summary)

                        If Not Directory.Exists(Shared_OpFile_path & "\Summary_Files") Then
                            Directory.CreateDirectory(Shared_OpFile_path & "\Summary_Files")
                        End If

                        My.Computer.FileSystem.CopyFile(Local_Folder_path & "\Backup_Files\" & Proc_Summary, Shared_OpFile_path & "\Summary_Files\" & Proc_Summary)

                        My.Computer.FileSystem.DeleteFile(Shared_Proc_Dir & "\" & Rename_File)

                    End If
                End If
            Next
        End If

    End Function

    Private Function Shared_drive()

        Dim xmldoc As New XmlDocument
        Dim xmlnode As XmlNodeList
        Dim xmlnode1 As XmlNodeList
        Dim File_Path As String

        File_Path = Directory.GetCurrentDirectory()

        xmldoc.Load(File_Path & "\Path_Config.xml")
        xmlnode = xmldoc.GetElementsByTagName("SharedLocation")

        Shared_Path = xmlnode(0).Attributes.ItemOf("Path").Value

        xmlnode1 = xmldoc.GetElementsByTagName("Remark")
        Remark_Config = xmlnode1(0).Attributes.ItemOf("Name").Value

    End Function

End Class
