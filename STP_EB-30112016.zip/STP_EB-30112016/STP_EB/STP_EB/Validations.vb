﻿Imports System.Data.OleDb
Imports System.IO
Imports Excel = Microsoft.Office.Interop.Excel
Imports System.Globalization
Imports System.Xml

Public Class Validations

    Public errmsg As String
    Public column_array As New ArrayList
    Public ds As New DataSet
    Dim result_conn As OleDbConnection
    Public txt_sl_no As String
    Public PHNO As String
    Public CERTNO As String
    Public DEPNO As String
    Public DOC As Date
    Public DOR As Date
    Public CONSLT As String
    Public BILLAMT As String
    Public Diag_Descp As String
    Public Diag_Code As String
    Public Doctor_Name As String
    Public Doctor_Code As String
    Public claim_type_csv As String
    Public patient_name As String
    Public member_num As String
    Public Dateofcon As String
    Public dateofrep As String
    Public remark1 As String
    Public remark2 As String
    Public remark3 As String
    Public remark4 As String
    Public remark_config As String
    Public Policy_Currency As String
    Public Indicator_CTC As String

    Public Amount_Claimed_Config As Integer
    Public DOR_Policies As New ArrayList
    Public DOR_Days As New ArrayList
    Public xmllist As New ArrayList

    Public Config_File As String
    Public Excel_File As String
    Public Local_Path As String
    Public csv_File_Name As String

    Public con As OleDbConnection

    Public Sub Main_Validation(csv_path As String, Config_Path As String, summaryfile As String, rmk As String)

        My.Computer.FileSystem.WriteAllBytes(summaryfile, My.Resources.Template, False)

        Config_File = Config_Path
        Excel_File = summaryfile
        csv_File_Name = Path.GetFileName(csv_path)
        remark_config = rmk

        get_configDetails()
        checking(csv_path)

        Form1.MetroLabel1.Text = Nothing
        Form1.Update()
        Form1.MetroLabel1.Text = "VALIDATION COMPLETE"
        Form1.Update()

    End Sub

    Sub checking(stppath As String)

        Dim sln As String
        Dim cnt1 As Integer

        'Provider=Microsoft.Jet.OLEDB.4.0; Data Source=C:\\;Extended Properties=\"Text;HDR=No;FMT=Delimited\""

        Dim filepath = My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\EB-Bot\" & csv_File_Name
        Dim stringReader As String
        Dim list = File.ReadAllLines(filepath).ToList()
        stringReader = list.Item(0).ToString()
        list.Insert(0, Strings.Replace(stringReader, """", ""))
        list.RemoveAt(1)
        File.WriteAllLines(filepath, list)

        'Provider=Microsoft.Jet.OLEDB.4.0
        Dim result_conn_col = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\EB-Bot;extended properties='text;HDR=Yes;cFMT=Delimited(,)';")
        result_conn_col.Open()
        'Dim ws_selectcmd As New OleDbDataAdapter("Select [Sl_No],[Policy Number],[Member Number],[Dependant Number],[Membership Number],[Patient Name],[Date of Consultation],[Date of Received],[Diagnosis Description],[Doctor Name],[Consultation Type 1],[Amount 1],[Currency],[Remark 1],[Remark 2],[Remark 3],[Remark 4] from [" & csv_File_Name & "]", result_conn)
        Dim ws_selectcmd_col As New OleDbDataAdapter("Select * from [" & csv_File_Name & "]", result_conn_col)
        '[Sl_No],[Claim Type],[Policy Number],[Member Number],[Dependant Number],[Membership Number],[Patient Name],[Date of Consultation],[Date of Received],[Diagnosis Description],[Diagnosis Code],[Doctor Name],[Doctor Code],[Consultation Type 1],[Amount 1], [Currency],[Remark 1],[Remark 2],[Remark 3],[Remark 4]
        ',""Claim Type"",""Policy Number"",""Member Number"",""Dependant Number"",""Membership Number"",""Patient Name"",""Date of Consultation"",""Date of Received"",""Diagnosis Description"",""Diagnosis Code"",""Doctor Name"",""Doctor Code"",""Consultation Type 1"",""Amount 1"",""Remark 1"",""Remark 2"",""Remark 3"",""Remark 4""
        'Dim ws_selectcmd As New OleDbDataAdapter("Select ['Sl_No'] from [" & csv_File_Name & "]", result_conn)
        'Dim ws_selectcmd As New OleDbDataAdapter("Select [Sl_No],[Claim Type],[Policy Number],[Member Number],[Dependant Number],[Membership Number],[Patient Name],[Date of Consultation],[Date of Received],[Diagnosis Description],[Diagnosis Code],[Doctor Name],[Doctor Code],[Consultation Type 1],[Amount 1],[Remark 1],[Remark 2],[Remark 3],[Remark 4] from [" & csv_File_Name & "]", result_conn)

        Dim ds_col As New DataSet
        ws_selectcmd_col.Fill(ds_col)

        result_conn_col.Dispose()
        ws_selectcmd_col.Dispose()
        result_conn_col.Close()

        cnt1 = 1

        Dim dir As DirectoryInfo = New DirectoryInfo(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\EB-Bot")
        Dim ini_files As FileInfo() = dir.GetFiles("schema.ini")
        If Not ini_files.Length = 0 Then
            For Each inifile As FileInfo In ini_files
                inifile.Delete()
            Next
        End If


        Dim sw As New System.IO.StreamWriter(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\EB-Bot\schema.ini", False)
        sw.WriteLine("[" & csv_File_Name & "]")
        sw.WriteLine("Format = CSVDelimited")
        sw.WriteLine("DecimalSymbol=.")
        For Each col As DataColumn In ds_col.Tables(0).Columns
            column_array.Add(col.ColumnName.ToString)
            sw.WriteLine("Col" & cnt1 & "=" & Chr(34) & col.ColumnName.ToString & Chr(34) & " Text")
            cnt1 = cnt1 + 1
        Next
        sw.Close()

        result_conn = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\EB-Bot;extended properties='text;HDR=Yes;cFMT=Delimited(,)';")
        result_conn.Open()
        Dim ws_selectcmd As New OleDbDataAdapter("Select * from [" & csv_File_Name & "]", result_conn)
        ws_selectcmd.Fill(ds)

        result_conn.Dispose()
        ws_selectcmd.Dispose()
        result_conn.Close()


        Form1.MetroLabel1.Text = Nothing
        Form1.Update()
        Form1.MetroLabel1.Text = "VALIDATING TEXT FILE"
        Form1.Update()
        Form1.MetroProgressBar1.Maximum = ds.Tables(0).Rows.Count
        Form1.Update()

        con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Excel_File & ";Extended properties=""Excel 12.0 Xml;HDR=YES"";")
        con.Open()


        For i = 0 To ds.Tables(0).Rows.Count - 1

            Form1.MetroLabel1.Text = Nothing
            Form1.Update()
            Form1.MetroProgressBar1.Value = i + 1
            Form1.MetroLabel1.Text = "VALIDATING RECORDS : " & i + 1 & " / " & ds.Tables(0).Rows.Count
            Form1.Update()

            txt_sl_no = GetStringValue("Sl_No", i)
            claim_type_csv = GetStringValue("Claim Type", i)
            PHNO = GetStringValue("Policy Number", i)
            CERTNO = GetStringValue("Member Number", i)
            DEPNO = GetStringValue("Dependant Number", i)
            member_num = GetStringValue("Membership Number", i)
            patient_name = GetStringValue("Patient Name", i)
            Dateofcon = GetStringValue("Date of Consultation", i)
            dateofrep = GetStringValue("Date of Received", i)
            Diag_Descp = GetStringValue("Diagnosis Description", i)
            Diag_Code = GetStringValue("Diagnosis Code", i)
            Doctor_Name = GetStringValue("Doctor Name", i)
            Doctor_Code = GetStringValue("Doctor Code", i)
            CONSLT = GetStringValue("Consultation Type 1", i)
            BILLAMT = GetStringValue("Amount 1", i)
            Policy_Currency = GetStringValue("Currency", i)
            remark1 = GetStringValue("Remark 1", i)
            remark2 = GetStringValue("Remark 2", i)
            remark3 = GetStringValue("Remark 3", i)
            remark4 = GetStringValue("Remark 4", i)
            Indicator_CTC = GetStringValue("Indicator of CTC", i)

            If Not Diag_Descp = "" Or Not Diag_Descp = Nothing Then
                Diag_Descp = Diag_Descp.ToUpper()
            End If

            If Not Doctor_Name = "" Or Not Doctor_Name = Nothing Then
                Doctor_Name = Doctor_Name.ToUpper()
            End If

            'txt_sl_no = GetStringValue(ds.Tables(0).Rows(i).ItemArray(0))
            'claim_type_csv = GetStringValue(ds.Tables(0).Rows(i).ItemArray(1))
            'PHNO = GetStringValue(ds.Tables(0).Rows(i).ItemArray(2))
            'CERTNO = GetStringValue(ds.Tables(0).Rows(i).ItemArray(3))
            'DEPNO = GetStringValue(ds.Tables(0).Rows(i).ItemArray(4))
            'member_num = GetStringValue(ds.Tables(0).Rows(i).ItemArray(5))
            'patient_name = GetStringValue(ds.Tables(0).Rows(i).ItemArray(6))
            'Dateofcon = GetStringValue(ds.Tables(0).Rows(i).ItemArray(7))
            'dateofrep = GetStringValue(ds.Tables(0).Rows(i).ItemArray(8))
            'Diag_Descp = GetStringValue(ds.Tables(0).Rows(i).ItemArray(9))
            'Diag_Code = GetStringValue(ds.Tables(0).Rows(i).ItemArray(10))
            'Doctor_Name = GetStringValue(ds.Tables(0).Rows(i).ItemArray(11))
            'Doctor_Code = GetStringValue(ds.Tables(0).Rows(i).ItemArray(12))
            'CONSLT = GetStringValue(ds.Tables(0).Rows(i).ItemArray(13))
            'BILLAMT = GetStringValue(ds.Tables(0).Rows(i).ItemArray(14))
            'Policy_Currency = GetStringValue(ds.Tables(0).Rows(i).ItemArray(15))
            'remark1 = GetStringValue(ds.Tables(0).Rows(i).ItemArray(16))
            'remark2 = GetStringValue(ds.Tables(0).Rows(i).ItemArray(17))
            'remark3 = GetStringValue(ds.Tables(0).Rows(i).ItemArray(18))
            'remark4 = GetStringValue(ds.Tables(0).Rows(i).ItemArray(19))

            If Indicator_CTC = Nothing Or Indicator_CTC = "" Then
                Indicator_CTC = "N"
            End If

            If Not remark1 = Nothing Or Not remark1 = "" Then
                remark1 = remark1.ToUpper()
            End If

            If Not remark2 = Nothing Or Not remark2 = "" Then
                remark2 = remark2.ToUpper()
            End If

            If Not remark3 = Nothing Or Not remark3 = "" Then
                remark4 = remark4.ToUpper()
            End If

            If Not remark4 = Nothing Or Not remark4 = "" Then
                remark4 = remark4.ToUpper()
            End If

            If remark4 = "" Or remark4 = Nothing Then
                If remark1 = remark_config Then
                    remark4 = remark1
                    remark1 = Nothing
                ElseIf remark2 = remark_config Then
                    remark4 = remark2
                    remark2 = Nothing
                ElseIf remark3 = remark_config Then
                    remark4 = remark3
                    remark3 = Nothing
                End If
            End If

            If Policy_Currency = Nothing Or Policy_Currency = "" Then
                Policy_Currency = "HKD"
            End If

            If claimtype(claim_type_csv) = False Then
                'Dim claimerror As String = errordescrp("CLAIM")
                exceptionhandling(errmsg)
            ElseIf phnofun(PHNO) = False Then
                'Dim phoerrdesc As String = errordescrp("PHNO")
                exceptionhandling(errmsg)
            ElseIf certfun(CERTNO) = False Then
                'Dim certnoerr As String = errordescrp("CERTNO")
                exceptionhandling(errmsg)
            ElseIf depnofun(DEPNO) = False Then
                'Dim depnoerr As String = errordescrp("DEPNO")
                exceptionhandling(errmsg)
            ElseIf consltfun(CONSLT) = False Then
                'Dim consulterr As String = errordescrp("CONSLT")
                exceptionhandling(errmsg)
            ElseIf Check_Diag(Diag_Descp) = False Then
                'Dim diagdescpri As String = errordescrp("DIAG")
                exceptionhandling(errmsg)
            ElseIf Check_Doctor(Doctor_Name, Doctor_Code) = False Then
                'Dim diagdescpri As String = errordescrp("DOCTOR")
                exceptionhandling(errmsg)
            ElseIf billfun() = False Then
                'Dim billerr As String = errordescrp("BILLAMT")
                exceptionhandling(errmsg)
            ElseIf docfun(Dateofcon, dateofrep, PHNO) = False Then
                'Dim docerr As String = errordescrp("DOC")
                exceptionhandling(errmsg)
            ElseIf Check_Remark(remark1, remark2, remark3, remark4) = False Then
                'Dim rmkerror As String = errordescrp("RMK")
                exceptionhandling(errmsg)
            Else
                passhandling()
            End If
        Next

        con.Dispose()
        con.Close()
        con = Nothing

    End Sub

    Function Check_Doctor(Doc_Name As String, Doc_Code As String) As Boolean

        Dim doc_code1 As New ArrayList
        Dim doc_eng_name As New ArrayList
        Dim doc_code_Index As Integer

        If Doc_Name = Nothing Or Doc_Name = "" Then
            errmsg = "DOCTOR NAME IS BLANK"
            Check_Doctor = False
        ElseIf Doctor_Code = Nothing Or Doctor_Code = "" Then
            Dim result_conn2 As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\EB-Bot\Configurable_Files;extended properties='text;HDR=Yes;cFMT=Delimited(,)';")
            result_conn2.Open()

            Dim selectcmd2 As New OleDbDataAdapter("Select [Code],[DR NAME (ENG)] from [Doctor_Codes.csv]", result_conn2)
            Dim ds2 As New DataSet
            selectcmd2.Fill(ds2)

            result_conn2.Dispose()
            result_conn2.Close()
            result_conn2 = Nothing

            For h = 0 To ds2.Tables(0).Rows.Count - 1
                doc_code1.Add(ds2.Tables(0).Rows(h).ItemArray(0).ToString.ToUpper)
                doc_eng_name.Add(ds2.Tables(0).Rows(h).ItemArray(1).ToString.ToUpper)
            Next

            If doc_eng_name.Contains(Doc_Name) Then
                doc_code_Index = doc_eng_name.IndexOf(Doc_Name)
                Doctor_Code = doc_code1.Item(doc_code_Index)
                If Doctor_Code = Nothing Or Doctor_Code = "" Then
                    errmsg = "DOCTOR CODE IS BLANK"
                    Check_Doctor = False
                Else

                    Check_Doctor = True
                End If
            Else
                errmsg = "DOCTOR NAME COULD NOT BE FOUND IN THE LIST"
                Check_Doctor = False
            End If

            'If ds2.Tables(0).Rows.Count = 0 Then
            '    Check_Doctor = False
            'ElseIf ds2.Tables(0).Rows(0).ItemArray(0).ToString = Nothing Or ds2.Tables(0).Rows(0).ItemArray(0).ToString = "" Then
            '    Check_Doctor = False
            'Else
            '    Doctor_Code = ds2.Tables(0).Rows(0).ItemArray(0).ToString
            '    Check_Doctor = True
            'End If
        Else
            Check_Doctor = True
        End If

    End Function

    Function get_configDetails()

        Dim XMLDoc As New XmlDocument
        Dim XMLNode As XmlNodeList
        Dim xlApp As Excel.Application
        Dim xlWorkBook As Excel.Workbook
        Dim xlWorkSheet As Excel.Worksheet
        Dim rows As Integer
        Dim spl_start_row As Integer

        spl_start_row = 3

        xlApp = New Excel.Application
        xlWorkBook = xlApp.Workbooks.Open(Filename:=Config_File, Password:="HCPEB")

        'get Maximum claim amount
        xlWorkSheet = xlWorkBook.Worksheets("AMOUNT CLAIMED")
        Amount_Claimed_Config = xlWorkSheet.Range("B7").Value

        'get Special policy list 
        xlWorkSheet = Nothing

        xlWorkSheet = xlWorkBook.Worksheets("DOR")

        For Each rang In xlWorkSheet.Range("A2:A" & xlWorkSheet.UsedRange.Rows.Count)
            DOR_Policies.Add(rang.Value)
        Next

        For Each rang1 In xlWorkSheet.Range("B2:B" & xlWorkSheet.UsedRange.Rows.Count)
            DOR_Days.Add(rang1.Value)
        Next

        'Store special policy numbers into arraylist
        xlWorkBook.Save()
        xlWorkBook.Close()
        xlApp.Quit()

        XMLDoc.Load(Directory.GetCurrentDirectory & "\Resources\Benefit_Header.xml")
        XMLNode = XMLDoc.GetElementsByTagName("Benefit")

        For i = 0 To XMLNode.Count - 1
            xmllist.Add(XMLNode(i).Attributes.ItemOf("Name").Value)
        Next

    End Function

    Function GetStringValue(val As String, j As Integer) As String

        Dim value As Object

        If column_array.Contains(val) Then
            value = ds.Tables(0).Rows(j).ItemArray(column_array.IndexOf(val))
            If value Is DBNull.Value Then
                GetStringValue = Nothing
            Else
                GetStringValue = value
            End If
        Else
            GetStringValue = Nothing
        End If

    End Function
    Function GetDateValue(ByVal value As Object) As Date
        If value Is DBNull.Value Then
            GetDateValue = Nothing
        Else
            GetDateValue = value
        End If
    End Function

    Private Function Check_Remark(rmk1 As String, rmk2 As String, rmk3 As String, rmk4 As String) As Boolean

        If rmk4 = remark_config Then
            Check_Remark = True
        ElseIf Indicator_CTC = "Y" And (rmk4 = "" Or rmk4 = Nothing) Then
            remark4 = remark_config
            Check_Remark = True
        ElseIf Indicator_CTC = "N" And Not rmk4 = remark_config Then
            Check_Remark = True
        Else
            errmsg = "REMARK CODE IS INVALID"
            Check_Remark = False
        End If

        'If Indicator_CTC = "N" And rmk4 = remark_config Then
        '    Check_Remark = False
        'ElseIf Indicator_CTC = "Y" And Not remark4 = remark_config Then
        '    Check_Remark = False
        'ElseIf (rmk4 = remark_config Or rmk4 = "" Or rmk4 = Nothing) And Indicator_CTC = "Y" Then
        '    remark4 = "CTC"
        '    Check_Remark = True
        'Else
        '    Check_Remark = False
        'End If

    End Function

    Function Check_Diag(diagdesc As String) As Boolean

        Dim descrp As New ArrayList
        Dim execp As New ArrayList
        Dim dg_code As New ArrayList
        Dim diag_Index As Integer

        Dim result_conn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\EB-Bot\Configurable_Files;extended properties='text;HDR=Yes;cFMT=Delimited(,)';")
        result_conn.Open()

        Dim selectcmd As New OleDbDataAdapter("select [DESCRIPTION],[Fall in exceptional report],[DIAGNOSIS CODE] from [Diagnosis_Code.csv]", result_conn)
        Dim ds As New DataSet
        selectcmd.Fill(ds)

        For i = 0 To ds.Tables(0).Rows.Count - 1
            descrp.Add(ds.Tables(0).Rows(i).ItemArray(0).ToString.ToUpper)
            execp.Add(ds.Tables(0).Rows(i).ItemArray(1).ToString.ToUpper)
            dg_code.Add(ds.Tables(0).Rows(i).ItemArray(2).ToString.ToUpper)
        Next

        result_conn.Close()
        result_conn = Nothing

        If descrp.Contains(diagdesc) Then
            diag_Index = descrp.IndexOf(diagdesc)
            If execp.Item(diag_Index).ToString = "Y" Then
                If Diag_Code = Nothing Or Diag_Code = "" Then
                    Diag_Code = dg_code.Item(diag_Index).ToString
                End If
                errmsg = "DIAGNOSIS DESCRIPTION FALLS IN EXCEPTION LIST"
                Check_Diag = False
            Else
                If Diag_Code = Nothing Or Diag_Code = "" Then
                    Diag_Code = dg_code.Item(diag_Index).ToString
                End If

                Check_Diag = True
            End If
        Else
            errmsg = "COULD NOT FIND DIAGNOSIS DESCRIPTION WITH IN THE FILE"
            Check_Diag = False
        End If

    End Function

    Function claimtype(claim_desc As String) As Boolean

        If claim_desc = "" Or claim_desc = Nothing Or claim_desc = "Clinical" Then
            claimtype = True
        Else
            errmsg = "INVALID CLAIM TYPE"
            claimtype = False
        End If

        'If claim_desc = "" Or claim_desc = Nothing Then
        '    claimtype = False
        'ElseIf Not claim_desc = "Clinical" Then
        '    claimtype = False
        'Else
        '    claimtype = True
        'End If

    End Function

    Function phnofun(Phno) As Boolean

        Dim phnovalue As String
        Dim polno2 As String

        polno2 = Left(Phno, 1)

        If Not Phno = "" Or Not Phno = Nothing Then
            If Left(Phno, 1) = "0" Or Left(Phno, 1) = "1" Or Left(Phno, 1) = "4" Then
                phnofun = True
            Else
                errmsg = "INVALID POLICY NUMBER"
                phnofun = False
            End If
        Else
            errmsg = "POLICY NUMBER IS BLANK"
            phnofun = False
        End If

    End Function
    Function certfun(certificatenum) As Boolean

        Dim certificatenum_val As String

        If Not certificatenum = "" Or Not certificatenum = Nothing Then
            certificatenum_val = Len(certificatenum)

            If certificatenum_val <= 7 Then
                certfun = True
            Else
                errmsg = "INVALID CERTIFICATE NUMBER"
                certfun = False
            End If
        Else
            errmsg = "CERTIFICATE NUMBER IS BLANK"
            certfun = False
        End If

    End Function
    Function depnofun(deptnum) As Boolean

        If deptnum = "" Or deptnum = Nothing Then
            errmsg = "DEPANDENT NUMBER IS BLANK"
            depnofun = False
        ElseIf deptnum > 10 Then
            errmsg = "DEPANDENT NUMBER IS INVALID"
            depnofun = False
        Else
            depnofun = True
        End If

    End Function
    Function consltfun(consulation) As Boolean

        Dim output As Integer

        If Not consulation = "" Or Not consulation = Nothing Then
            If xmllist.Contains(consulation) Then
                If IsNumeric(BILLAMT) And Integer.TryParse(BILLAMT, output) Then
                    consltfun = True
                ElseIf consulation = "Chinese Herbalist" And IsNumeric(BILLAMT) Then
                    consltfun = True
                Else
                    errmsg = "AMOUNT IS BLANK OR INVALID FOR THE CORRESPONDING CONSULTATION"
                    consltfun = False
                End If
            Else
                errmsg = "INVALID CONSULTATION TYPE"
                consltfun = False
            End If
        Else
            errmsg = "CONSULTATION TYPE IS BLANK"
            consltfun = False
        End If

    End Function
    Function sclmfun(sclm) As Boolean
        If sclm = "" Then
            sclmfun = False
        ElseIf sclm = "Y" Then
            sclmfun = False
        ElseIf sclm = "N" Then
            sclmfun = True
        Else
            sclmfun = False
        End If
        sclmfun = sclmfun
    End Function
    Function matefun(maternity) As Boolean
        If maternity = " " Then
            matefun = False
        ElseIf maternity = "Y" Then
            matefun = False
        ElseIf maternity = "N" Then
            matefun = True
        Else
            matefun = False
        End If

        matefun = matefun
    End Function
    Function billfun()

        billfun = False

        Dim Amount As Double

        If Not BILLAMT = "" Or Not BILLAMT = Nothing Then

            Amount = Convert.ToDouble(BILLAMT)
            If Amount > Amount_Claimed_Config Then
                errmsg = "AMOUNT CLAIMED IS INVALID"
                billfun = False
            ElseIf Amount <= Amount_Claimed_Config Then
                billfun = True
            End If
        Else
            errmsg = "AMOUNT CLAIMED IS BLANK"
            billfun = False
        End If

    End Function
    Function docfun(doc1 As String, dor1 As String, phno As String)

        Dim index As Integer
        Dim No_of_days As Integer
        Dim span As Long
        docfun = True

        On Error GoTo vald
        If Not doc1 = "" Or Not doc1 = Nothing Or Not dor1 = "" Or Not dor1 = Nothing Then
            DOC = DateTime.ParseExact(doc1, "yyyyMMdd", CultureInfo.InvariantCulture)
            DOR = DateTime.ParseExact(dor1, "yyyyMMdd", CultureInfo.InvariantCulture)

            span = DateDiff(DateInterval.Day, DOC, DOR)

            If DOR_Policies.Contains(phno) Then
                index = DOR_Policies.IndexOf(phno)
                No_of_days = DOR_Days(index)

                If span > No_of_days Then
                    errmsg = "CLAIM HAS PASSED THE POLICY SPECIFIC SUBMISSION PERIOD"
                    docfun = False
                Else
                    docfun = True
                End If
            ElseIf Strings.Left(phno, 1) = "1" Or Strings.Left(phno, 1) = "4" Then
                If span > 60 Then
                    errmsg = "CLAIM HAS PASSED THE POLICY SPECIFIC SUBMISSION PERIOD"
                    docfun = False
                Else
                    docfun = True
                End If
            ElseIf Strings.Left(phno, 1) = "0" Then
                If span > 90 Then
                    errmsg = "CLAIM HAS PASSED THE POLICY SPECIFIC SUBMISSION PERIOD"
                    docfun = False
                Else
                    docfun = True
                End If
            End If
        Else
vald:
            errmsg = "DOC is Blank"
            docfun = False
        End If

    End Function

    Function errordescrp(str As String) As String

        If str = "PHNO" Then
            errordescrp = "INCORRECT POLICY NUMBER"
        ElseIf str = "CLAIM" Then
            errordescrp = "INCORRECT CLAIM TYPE"
        ElseIf str = "CERTNO" Then
            errordescrp = "INCORRECT MEMBER NUMBER"
        ElseIf str = "DEPNO" Then
            errordescrp = "INCORRECT DEPENDENT NUMBER"
        ElseIf str = "CONSLT" Then
            errordescrp = "INCORRECT CONSULTATION TYPE"
        ElseIf str = "DIAG" Then
            errordescrp = "DIAGNOSIS DESCRIPTION FALLS UNDER EXCEPTION"
        ElseIf str = "DOCTOR" Then
            errordescrp = "DOCTOR NAME IS BLANK"
        ElseIf str = "BILLAMT" Then
            errordescrp = "AMOUNT EXCEEDED/INVALID"
        ElseIf str = "DOC" Then
            errordescrp = "CLAIM HAS PASSED THE POLICY SPECIFIC SUBMISSION PERIOD"
        ElseIf str = "SClm" Then
            errordescrp = "SECOND CLAIM FLAGGED"
        ElseIf str = "MaternityClm" Then
            errordescrp = "Maternity Related Flagged"
        ElseIf str = "RMK" Then
            errordescrp = "INCORRECT REMARK CODE (CTC FLAG)"
        Else
            errordescrp = "Diagnosis code Not To be processed"
        End If
    End Function

    Function exceptionhandling(description As String)

        'Dim Cnt As Integer = 0

        'Cnt = GetCount("Exceptions$") + 1

        'Dim excep_update As New OleDbCommand("Insert Into [Exceptions$] ([SL_NO],[USERNAME],[CLAIM_TYPE],[PROCESSING DATE],[POLICY NUMBER],[MEMBER NUMBER],[DEPENDENT NO],[DATE OF CONSULTATION],[CONSULTATION TYPE],[DIAGNOSIS TEXT],[DIAGNOSIS CODE],[DOCTOR NAME],[DOCTOR CODE],[AMOUNT TO BE CLAIMED],[EXCEPTION DESCRIPTION],[DATE OF RECEIPT],[PATIENT NAME],[MEMBERSHIP NUMBER],[REMARK CODE 4]) values('" & Convert.ToInt32(Cnt) & "','" & Environment.UserName & "','" & claim_type_csv & "','" & Now.Date & "','" & PHNO & "','" & CERTNO & "','" & DEPNO & "','" & Dateofcon & "','" & Replace(CONSLT, "'", "''") & "','" & Replace(Diag_Descp, "'", "''") & "','" & Diag_Code & "','" & Replace(Doctor_Name, "'", "''") & "','" & Doctor_Code & "','" & BILLAMT & "','" & description & "','" & dateofrep & "','" & Replace(patient_name, "'", "''") & "','" & member_num & "','" & Replace(remark4, "'", "''") & "')", con)
        Dim excep_update As New OleDbCommand("Insert Into [Exceptions$] ([SL_NO],[USERNAME],[CLAIM_TYPE],[PROCESSING DATE],[POLICY NUMBER],[MEMBER NUMBER],[DEPENDENT NO],[DATE OF CONSULTATION],[CONSULTATION TYPE],[DIAGNOSIS TEXT],[DIAGNOSIS CODE],[DOCTOR NAME],[DOCTOR CODE],[AMOUNT TO BE CLAIMED],[EXCEPTION DESCRIPTION],[DATE OF RECEIPT],[PATIENT NAME],[MEMBERSHIP NUMBER],[REMARK CODE 4],[REMARK CODE 3],[REMARK CODE 2],[REMARK CODE 1],[CURRENCY],[INDICATOR OF CTC]) values('" & txt_sl_no & "','" & Environment.UserName & "','" & claim_type_csv & "','" & Now.Date & "','" & PHNO & "','" & CERTNO & "','" & DEPNO & "','" & Dateofcon & "','" & Replace(CONSLT, "'", "''") & "','" & Replace(Diag_Descp, "'", "''") & "','" & Diag_Code & "','" & Replace(Doctor_Name, "'", "''") & "','" & Doctor_Code & "','" & BILLAMT & "','" & description & "','" & dateofrep & "','" & Replace(patient_name, "'", "''") & "','" & member_num & "','" & Replace(remark4, "'", "''") & "','" & Replace(remark3, "'", "''") & "','" & Replace(remark2, "'", "''") & "','" & Replace(remark1, "'", "''") & "','" & Policy_Currency & "','" & Indicator_CTC & "')", con)
        excep_update.ExecuteNonQuery()
        excep_update.Dispose()
        'Cnt = Nothing
        excep_update = Nothing

    End Function
    Function passhandling()

        'Dim Cnt1 As Integer = 0

        'Cnt1 = GetCount("Pass$") + 1

        'Dim pass_update As New OleDbCommand("Insert Into [Pass$] ([SL_NO],[USERNAME],[CLAIM_TYPE],[POLICY NUMBER],[MEMBER NUMBER],[DEPENDENT NO],[DATE OF CONSULTATION],[CONSULTATION TYPE],[DIAGNOSIS TEXT],[DIAGNOSIS CODE],[DOCTOR NAME],[DOCTOR CODE],[AMOUNT TO BE CLAIMED],[DATE OF RECEIPT],[PATIENT NAME],[MEMBERSHIP NUMBER],[REMARK CODE 4]) values('" & Convert.ToInt32(Cnt1) & "','" & Environment.UserName & "','" & claim_type_csv & "','" & PHNO & "','" & CERTNO & "','" & Convert.ToInt32(DEPNO) & "','" & DOC.ToString("yyyyMMdd") & "','" & Replace(CONSLT, "'", "''") & "','" & Replace(Diag_Descp, "'", "''") & "','" & Diag_Code & "','" & Replace(Doctor_Name, "'", "''") & "','" & Doctor_Code & "','" & Convert.ToDouble(BILLAMT) & "','" & DOR.ToString("yyyyMMdd") & "','" & Replace(patient_name, "'", "''") & "','" & member_num & "','" & Replace(remark4, "'", "''") & "')", con)
        Dim pass_update As New OleDbCommand("Insert Into [Pass$] ([SL_NO],[USERNAME],[CLAIM_TYPE],[POLICY NUMBER],[MEMBER NUMBER],[DEPENDENT NO],[DATE OF CONSULTATION],[CONSULTATION TYPE],[DIAGNOSIS TEXT],[DIAGNOSIS CODE],[DOCTOR NAME],[DOCTOR CODE],[AMOUNT TO BE CLAIMED],[DATE OF RECEIPT],[PATIENT NAME],[MEMBERSHIP NUMBER],[REMARK CODE 4],[REMARK CODE 3],[REMARK CODE 2],[REMARK CODE 1],[CURRENCY],[INDICATOR OF CTC]) values('" & txt_sl_no & "','" & Environment.UserName & "','" & claim_type_csv & "','" & PHNO & "','" & CERTNO & "','" & Convert.ToInt32(DEPNO) & "','" & DOC.ToString("yyyyMMdd") & "','" & Replace(CONSLT, "'", "''") & "','" & Replace(Diag_Descp, "'", "''") & "','" & Diag_Code & "','" & Replace(Doctor_Name, "'", "''") & "','" & Doctor_Code & "','" & Convert.ToDouble(BILLAMT) & "','" & DOR.ToString("yyyyMMdd") & "','" & Replace(patient_name, "'", "''") & "','" & member_num & "','" & Replace(remark4, "'", "''") & "','" & Replace(remark3, "'", "''") & "','" & Replace(remark2, "'", "''") & "','" & Replace(remark1, "'", "''") & "','" & Policy_Currency & "','" & Indicator_CTC & "')", con)
        pass_update.ExecuteNonQuery()
        pass_update.Dispose()
        'Cnt1 = Nothing

    End Function

    Private Function GetCount(Sheet_Name As String)

        Dim ad As New OleDbDataAdapter("Select * From [" & Sheet_Name & "]", con)
        Dim dt As New DataSet()

        ad.Fill(dt)

        GetCount = dt.Tables(0).Rows.Count

        ad.Dispose()
        ad = Nothing

    End Function

End Class
