﻿Imports IBMISeries
Imports MetroFramework
Imports System.Xml
Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel
Imports System.IO
Imports System.Threading

Public Class Claim_Processing

    Public No_Verify As Boolean = False
    Public First_Error As Boolean = False
    Public Shared_Path As String
    Public Unknown_Err As Boolean = False
    Public Claim_File As String
    Public Config As String
    Public Summary_File As String

    Public Session_ID As String
    Public Paid_Amount As Double
    Public Window_Title As String

    Public Claim_No As String
    Public Pay_To As String
    Public Stat As String
    Public Remark As String
    Public Amount_paid As String
    Public Con As OleDbConnection
    Public Currency_Conv As String
    Public No_Bene_Flag As Boolean = False
    Public Benefit_Flag As Boolean = False
    Public Well_Flag As Boolean = False

    Public Amount_Claimed_Pos As Integer
    Public Consult_Type As String
    Public Doctor_Code As String
    Public Policy_Currency As String
    Public Amount As Double
    Public Amountpaid_Pos As Integer

    Public Benefit_Headers As New ArrayList
    Public Special_Policy As New ArrayList
    Public Currency_List As New ArrayList
    Public Exchange_Rate As New ArrayList
    Public maxday_error_hand As New ArrayList
    Public Special_Doctor As New ArrayList
    Public SP_Doc_Benefit As New ArrayList

    Public Sub RLS_Extraction(ConfigFile As String, SummaryFile As String)

        Shared_drive()
        Claim_File = SummaryFile
        Config = ConfigFile

        Form1.MetroLabel1.Text = Nothing
        Form1.Update()
        Form1.MetroLabel1.Text = "Sign-On In-Progress"
        Form1.Update()
        Sign_On()

        Form1.MetroLabel1.Text = Nothing
        Form1.Update()
        Form1.MetroLabel1.Text = "Capturing Exchange Rate"
        Form1.Update()
        Read_Ex_Rate()

        Load_Policies()

        Form1.MetroLabel1.Text = Nothing
        Form1.Update()
        Form1.MetroLabel1.Text = "Processing Claims"
        Form1.Update()
        Process_Claim()

        Form1.MetroLabel1.Text = "Successfully processed the file"
        Form1.Update()

        Screen_Flow("GP30004", "Back_Home")

    End Sub

    '*********************************************************************************
    'Function Name  - Read_Data()
    'Parameters     - Excel file
    'Description    - Extract the input data required to process a claim in EB
    '*********************************************************************************
    Private Function Process_Claim()

        Screen_Flow("GP30004", "Flow")

        Dim Policy_No As String
        Dim Cert_No As String
        Dim Depn_No As String
        Dim DOC As String
        Dim DOR As String
        'Dim Consult_Type As String
        Dim Diag_Code As String
        'Dim Amount As Double
        'Dim Doctor_Code As String
        Dim EB_Status As String
        Dim Verify_mess As String
        Dim Sl_No As String
        Dim Gp304_Scrn As String
        Dim processing_status As String
        Dim remark4 As String
        Dim remark3 As String
        Dim remark2 As String
        Dim remark1 As String

        Dim first_Currency As Boolean = False

        Dim Currency_Onscrn As String
        Dim Currency_Index As Integer
        Dim Currency_Val As Double

        'Dim Amountpaid_Pos As Integer

        Dim Proc_Scrn As String
        Dim Counter As Integer = 1

        Load_Policies()

        Con = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Claim_File & ";Extended Properties=Excel 12.0 Macro")
        Con.Open()
        Dim Adap As New OleDbDataAdapter("Select [POLICY NUMBER],[MEMBER NUMBER],[DEPENDENT NO],[DATE OF CONSULTATION],[CONSULTATION TYPE],[DIAGNOSIS CODE],[AMOUNT TO BE CLAIMED],[SL_NO],[DATE OF RECEIPT],[DOCTOR CODE],[CLAIM PROCESSING STATUS (Y/N)],[REMARK CODE 4],[REMARK CODE 3],[REMARK CODE 2],[REMARK CODE 1],[CURRENCY] From [Pass$]", Con)
        Dim dt As New DataSet
        Adap.Fill(dt)

        Form1.MetroProgressBar1.Maximum = dt.Tables(0).Rows.Count

        For i = 0 To dt.Tables(0).Rows.Count - 1

            Unknown_Err = False
            First_Error = False
            No_Verify = False

            Form1.MetroLabel1.Text = Nothing
            Form1.Update()
            Form1.MetroProgressBar1.Value = i + 1
            Form1.MetroProgressBar1.Update()
            Form1.MetroLabel1.Text = "Processing Claims : " & i + 1 & " / " & dt.Tables(0).Rows.Count
            Form1.MetroLabel1.Update()
            Form1.Update()

            Currency_Conv = "N"
            No_Bene_Flag = False
            Benefit_Flag = False
            Well_Flag = False

            Policy_No = GetStringValue(Strings.Left(dt.Tables(0).Rows(i).ItemArray(0), 6))

            Cert_No = GetStringValue(dt.Tables(0).Rows(i).ItemArray(1))
            Cert_No = GetStringValue(Cert_No.ToString.PadLeft(7, " "))


            Depn_No = GetStringValue(dt.Tables(0).Rows(i).ItemArray(2))
            Depn_No = GetStringValue(Depn_No.ToString.PadLeft(2, "0"))

            DOC = GetStringValue(dt.Tables(0).Rows(i).ItemArray(3))
            Consult_Type = GetStringValue(dt.Tables(0).Rows(i).ItemArray(4))
            Diag_Code = GetStringValue(dt.Tables(0).Rows(i).ItemArray(5))
            Amount = GetStringValue(dt.Tables(0).Rows(i).ItemArray(6))
            Sl_No = GetStringValue(dt.Tables(0).Rows(i).ItemArray(7))
            DOR = GetStringValue(dt.Tables(0).Rows(i).ItemArray(8))
            Doctor_Code = GetStringValue(dt.Tables(0).Rows(i).ItemArray(9))
            Doctor_Code = GetStringValue(Doctor_Code.ToString.PadLeft(5, " "))
            processing_status = GetStringValue(dt.Tables(0).Rows(i).ItemArray(10))
            remark4 = GetStringValue(dt.Tables(0).Rows(i).ItemArray(11))
            remark3 = GetStringValue(dt.Tables(0).Rows(i).ItemArray(12))
            remark2 = GetStringValue(dt.Tables(0).Rows(i).ItemArray(13))
            remark1 = GetStringValue(dt.Tables(0).Rows(i).ItemArray(14))
            Policy_Currency = GetStringValue(dt.Tables(0).Rows(i).ItemArray(15))

            If remark4 = Nothing Then
                remark4 = " "
            End If

            If remark3 = Nothing Then
                remark3 = " "
            End If

            If remark2 = Nothing Then
                remark2 = " "
            End If

            If remark1 = Nothing Then
                remark1 = " "
            End If

            If Not processing_status = "Y" Then

                Wrapper.HLL_CopyStringToPS(Policy_No, Wrapper.getPos(4, 7))
                Wrapper.HLL_CopyStringToPS(Cert_No, Wrapper.getPos(4, 22))
                Wrapper.HLL_CopyStringToPS(Depn_No, Wrapper.getPos(4, 37))
                Wrapper.HLL_CopyStringToPS(DOC, Wrapper.getPos(4, 45))

                Wrapper.SendStr("@E")

                Do
                    EB_Status = Nothing
                    EB_Status = Read_StatusBar()

                    If Not EB_Status = Nothing Or Not EB_Status = "" Then
                        Wrapper.SendStr("#@")
                        Wrapper.HLL_Wait()
                        First_Error = True
                        Capture_Details(EB_Status, 0, Sl_No)
                    Else
                        Wrapper.HLL_ReadScreen(Wrapper.getPos(1, 2), 7, Proc_Scrn)
                        Proc_Scrn = Trim(Strings.Left(Proc_Scrn, 7))
                        If Proc_Scrn = "GP30003" Or Proc_Scrn = "GP30004" Then
                            Exit Do
                        End If
                    End If
                Loop Until (Not EB_Status = Nothing Or Not EB_Status = "" Or Proc_Scrn = "GP30003" Or Proc_Scrn = "GP30004")

                If First_Error = True Then
                    Continue For
                End If

                Proc_Scrn = Nothing
                Wrapper.HLL_ReadScreen(Wrapper.getPos(1, 2), 7, Proc_Scrn)
                Proc_Scrn = Trim(Strings.Left(Proc_Scrn, 7))

                Do Until Proc_Scrn = "GP30004​"
                    Proc_Scrn = Nothing

                    Wrapper.HLL_ReadScreen(Wrapper.getPos(1, 2), 7, Proc_Scrn)
                    Proc_Scrn = Trim(Strings.Left(Proc_Scrn, 7))

                    If Proc_Scrn = "GP30004" Then
                        Exit Do
                    Else
                        Wrapper.SendStr("@E")
                        Wrapper.HLL_Wait()
                    End If
                Loop

                Wrapper.HLL_CopyStringToPS(Doctor_Code, Wrapper.getPos(15, 74))         'Send Doctor Code
                Wrapper.HLL_CopyStringToPS(Diag_Code, Wrapper.getPos(16, 7))            'Send Diagnosis Code
                Wrapper.HLL_CopyStringToPS("P", Wrapper.getPos(16, 21))                 'Send Status as P
                Wrapper.HLL_CopyStringToPS("          ", Wrapper.getPos(17, 31))        'Delete current DOR
                Wrapper.HLL_CopyStringToPS(DOR, Wrapper.getPos(17, 31))                 'Input DOR
                Wrapper.HLL_CopyStringToPS(remark1, Wrapper.getPos(16, 27))             'Input Remark code to the First field
                Wrapper.HLL_CopyStringToPS(remark2, Wrapper.getPos(16, 32))             'Input Remark code to the Second field
                Wrapper.HLL_CopyStringToPS(remark3, Wrapper.getPos(16, 37))             'Input Remark code to the Third field
                Wrapper.HLL_CopyStringToPS(remark4, Wrapper.getPos(16, 42))             'Input Remark code to the fourth field

                Wrapper.HLL_ReadScreen(Wrapper.getPos(4, 6), 3, Currency_Onscrn)
                Currency_Onscrn = Trim(Strings.Left(Currency_Onscrn, 3))

                If Not Policy_Currency = "HKD" And Not Currency_Onscrn = Policy_Currency Then
                    If Currency_List.Contains(Policy_Currency) Then
                        Currency_Index = Currency_List.IndexOf(Policy_Currency)
                        Currency_Val = Exchange_Rate(Currency_Index)
                        Amount = Amount * Currency_Val
                        Amount = Math.Round(Amount, 2)
                    Else
                        first_Currency = True
                        Mark_C("Currency not found in currency list", Sl_No, 0)
                        Continue For
                    End If
                End If

                Currency_Index = Nothing
                Currency_Val = Nothing

                If Currency_Onscrn = "HKD" And Not Policy_Currency = "HKD" Then
                    Currency_List.Add("HKD")
                    Exchange_Rate.Add("1.00")
                End If

                If first_Currency = False Then
                        If Not Currency_Onscrn = Policy_Currency Then
                            If Currency_List.Contains(Currency_Onscrn) Then
                                Currency_Index = Currency_List.IndexOf(Currency_Onscrn)
                                Currency_Val = Exchange_Rate(Currency_Index)
                                Amount = Amount / Currency_Val
                                Amount = Math.Round(Amount, 2)
                                Currency_Conv = "Y"
                            Else
                                Mark_C("Currency not found in currency list", Sl_No, 0)
                                Continue For
                            End If
                        End If
                    End If

                    Amountpaid_Pos = Capture_Benefit(Consult_Type, Amount, Policy_No)                  'Send Amount to be claimed

                    If No_Bene_Flag = True Or Benefit_Flag = True Then
                        If Well_Flag = True Then
                            Mark_C("WELL BENEFIT NOT FOUND", Sl_No, Amountpaid_Pos)
                        Else
                            Capture_Details("NO BENEFITS FOUND", Amountpaid_Pos, Sl_No)
                            Wrapper.SendStr("@E")
                            Wrapper.HLL_Wait()
                        End If
                        'Mark_C("No benefits found", Sl_No, 0)
                        'Wrapper.SendStr("#@")
                        'Wrapper.HLL_Wait()
                        'Wrapper.HLL_CopyStringToPS("R", Wrapper.getPos(16, 21))
                        Continue For
                    End If

                    'SPECIAL HANDLING POLICIES TO BE MARKED AS EXCEPTION
                    If Special_Policy.Contains(Policy_No) Then
                        Mark_C("Special Handling Policy", Sl_No, Amountpaid_Pos)
                        Continue For
                    End If

                    Wrapper.SendStr("@E")
                    Wrapper.HLL_Pause(Session_ID, 2)
                    EB_Status = Read_StatusBar() 'Read status bar for errors
                    Wrapper.SendStr("#@")
                    Wrapper.HLL_Wait()

                    Wrapper.HLL_ReadScreen(Wrapper.getPos(22, 40), 37, Verify_mess)

                    Verify_mess = Trim(Strings.Left(Verify_mess, 37))

                    If Verify_mess = "*** PLEASE VERIFY & PRESS <ENTER> ***" Then

                        Capture_Details(EB_Status, Amountpaid_Pos, Sl_No)
                        Wrapper.SendStr("@E")
                        Pause_Function()

                        EB_Status = Nothing
                        EB_Status = Read_StatusBar()

                        Wrapper.SendStr("#@")
                        Wrapper.HLL_Wait()

                        If Not EB_Status = "" Or Not EB_Status = Nothing Then
                            Error_Case(EB_Status, Amountpaid_Pos, Policy_No)

                            If Unknown_Err = True Then
                                Mark_C("Invalid Error - " & EB_Status, Sl_No, Amountpaid_Pos)
                                Continue For
                            End If

                            Capture_Details(EB_Status, Amountpaid_Pos, Sl_No)

                            If Stat = "R" Then
                                Wrapper.SendStr("@E")
                                Wrapper.HLL_Wait()
                            Else
                                Wrapper.SendStr("@E")
                                Pause_Function()
                            End If
                        End If
                    Else
                        No_Verify = True
                        Error_Case(EB_Status, Amountpaid_Pos, Policy_No)

                        If Unknown_Err = True Then
                            Mark_C("Invalid Error - " & EB_Status, Sl_No, Amountpaid_Pos)
                            Continue For
                        End If

                        Capture_Details(EB_Status, Amountpaid_Pos, Sl_No)

                        If Stat = "R" Then
                            Wrapper.SendStr("@E")
                            Wrapper.HLL_Wait()
                        Else
                            Wrapper.SendStr("@E")
                            Pause_Function()
                        End If

                        EB_Status = Nothing
                        EB_Status = Read_StatusBar()
                        Wrapper.SendStr("#@")
                        Wrapper.HLL_Wait()
                        If Not EB_Status = "" Or Not EB_Status = Nothing Then
                            Error_Case(EB_Status, Amountpaid_Pos, Policy_No)

                            If Unknown_Err = True Then
                                Mark_C("Invalid Error - " & EB_Status, Sl_No, Amountpaid_Pos)
                                Continue For
                            End If

                            Capture_Details(EB_Status, Amountpaid_Pos, Sl_No)

                            If Stat = "R" Then
                                Wrapper.SendStr("@E")
                                Wrapper.HLL_Wait()
                            Else
                                Wrapper.SendStr("@E")
                                Pause_Function()
                            End If

                        End If
                    End If

                    Wrapper.SendStr("#@")
                    Wrapper.HLL_Wait()

                    Wrapper.HLL_ReadScreen(Wrapper.getPos(1, 2), 7, Gp304_Scrn)
                    Gp304_Scrn = Trim(Strings.Left(Gp304_Scrn, 7))

                    Wrapper.SendStr("#@")
                    Wrapper.HLL_Wait()

                    If Not Gp304_Scrn = "GP30002" Then
                        Mark_C("CANNOT BE PROCESSED", Sl_No, Amountpaid_Pos)
                        Wrapper.SendStr("#@")
                        Wrapper.HLL_Wait()
                    End If
                    Counter = Counter + 1
                End If
        Next

        Con.Close()
        Con = Nothing

    End Function

    Function GetStringValue(ByVal value As Object) As String

        If value Is DBNull.Value Then
            GetStringValue = Nothing
        Else
            GetStringValue = value
        End If

    End Function

    '*********************************************************************************
    'Function Name  - Pause_Function()
    'Parameters     - 
    'Description    - Pause the execution until u get an error or Get back to the main screen
    'Return         - Nothing
    '*********************************************************************************

    Private Function Pause_Function()

        Dim status_EB As String
        Dim Proc_Scrn As String
        Dim Verify_mess As String

        Do
            status_EB = Nothing
            Proc_Scrn = Nothing

            status_EB = Read_StatusBar()
            Wrapper.HLL_ReadScreen(Wrapper.getPos(1, 2), 7, Proc_Scrn)
            Proc_Scrn = Trim(Strings.Left(Proc_Scrn, 7))

            If Proc_Scrn = "GP30002" Or Not status_EB = Nothing Or Not status_EB = "" Then
                Exit Do
            End If

        Loop Until (Not status_EB = Nothing Or Not status_EB = "" Or Proc_Scrn = "GP30002")

    End Function

    '*********************************************************************************
    'Function Name  - Load_Policies()
    'Parameters     - 
    'Description    - Function to load all the special handling policies from Config
    'Return         - Nothing
    '*********************************************************************************
    Private Function Load_Policies()

        Dim xlapp As New Excel.Application
        Dim xlwb As Excel.Workbook = xlapp.Workbooks.Open(Config, Password:="HCPEB") 'Excel workbook to store the PDF table
        Dim xlsheet As Excel.Worksheet
        Dim rang As Excel.Range

        xlsheet = xlwb.Worksheets("SPECIAL POLICYHANDLING")

        For Each rang In xlsheet.Range("A2:A" & xlsheet.UsedRange.Rows.Count)
            Special_Policy.Add(rang.Value)
        Next

        xlsheet = Nothing

        xlsheet = xlwb.Worksheets("CCY")

        For Each rang1 In xlsheet.Range("A2:A" & xlsheet.UsedRange.Rows.Count)
            If Not rang1.Value = Nothing Or Not rang1.Value = "" Then
                Currency_List.Add(rang1.Value)
            End If
        Next

        For Each rang2 In xlsheet.Range("B2:B" & xlsheet.UsedRange.Rows.Count)
            Exchange_Rate.Add(rang2.Value)
        Next

        xlsheet = Nothing

        xlsheet = xlwb.Worksheets("MAX DAY COUNT")

        For Each rang3 In xlsheet.Range("A2:A" & xlsheet.UsedRange.Rows.Count)
            maxday_error_hand.Add(rang3.Value)
        Next

        xlsheet = Nothing

        'xlsheet = xlwb.Worksheets("DOCTOR_CODE")

        'For Each rang4 In xlsheet.Range("A2:A" & xlsheet.UsedRange.Rows.Count)
        '    Special_Doctor.Add(rang4.Value.ToString.PadLeft(5, " "))
        'Next

        'For Each rang5 In xlsheet.Range("B2:B" & xlsheet.UsedRange.Rows.Count)
        '    SP_Doc_Benefit.Add(rang5.Value)
        'Next

        xlwb.Save()
        xlwb.Close()
        xlapp.Quit()
        xlwb = Nothing
        xlapp = Nothing

    End Function

    '*********************************************************************************
    'Function Name  - Mark_C()
    'Parameters     - Error Message, Amount Paid Position, Serial Number
    'Description    - Marks the claim as exception
    'Return         - Nothing
    '*********************************************************************************

    Private Function Mark_C(Err_Message As String, SL_NO As String, Amountpaid_Position As Integer) 'error fixed

        Dim status_markc As String
        Dim Scrn_Name As String

        Wrapper.SendStr("#@")
        Wrapper.HLL_Wait()

        Wrapper.HLL_CopyStringToPS("C", Wrapper.getPos(16, 21)) 'Update Status
        Capture_Details(Err_Message, Amountpaid_Position, SL_NO)
        Wrapper.SendStr("@E")
        Pause_Function()

        status_markc = Nothing
        status_markc = Read_StatusBar()

        Wrapper.SendStr("#@")
        Wrapper.HLL_Wait()

        If status_markc = "STATUS MUST BE 'R'" Then
            Wrapper.HLL_CopyStringToPS("R", Wrapper.getPos(16, 21)) 'Update Status
            Wrapper.HLL_CopyStringToPS("    ", Wrapper.getPos(16, 27)) 'Update Remark
            Wrapper.HLL_CopyStringToPS("999", Wrapper.getPos(16, 27)) 'Update Remark
            Wrapper.HLL_CopyStringToPS("         ", Amountpaid_Position) 'Delete Amount Paid
            Capture_Details(status_markc, Amountpaid_Position, SL_NO)
            Wrapper.SendStr("@E")
            Wrapper.HLL_Wait()
        Else
            Wrapper.HLL_ReadScreen(Wrapper.getPos(1, 2), 7, Scrn_Name)
            Scrn_Name = Trim(Strings.Left(Scrn_Name, 7))

            If Not Scrn_Name = "GP30002" Then
                Stat = ""
                First_Error = True
                Capture_Details("CANNOT BE PROCESSED, F1 PRESSED", Amountpaid_Position, SL_NO)
                Wrapper.SendStr("@1")
                Wrapper.HLL_Wait()
            End If
        End If

    End Function

    '*********************************************************************************
    'Function Name  - Capture_Details()
    'Parameters     - Error Message, Amount Paid Position
    'Description    - Captures the Claim details
    'Return         - Nothing
    '*********************************************************************************

    Private Function Capture_Details(Err_Status As String, Amount_Paid_Screen As Double, SL_NO As String)

        Dim Todays_Date As Date
        Dim Processing_Flag As String
        Dim Patient_Name As String

        Dim cmd As OleDbCommand

        Processing_Flag = "Y"
        Todays_Date = Date.Now.Date

        If First_Error = True Then
            Claim_No = Nothing
            Pay_To = Nothing
            Stat = Nothing
            Remark = Nothing
            Amount_paid = Nothing
            Patient_Name = Nothing
        Else
            Wrapper.HLL_ReadScreen(Wrapper.getPos(15, 23), 9, Claim_No)     'GET THE CLAIM NUMBER
            Claim_No = Trim(Strings.Left(Claim_No, 9))
            Wrapper.HLL_ReadScreen(Wrapper.getPos(15, 55), 2, Pay_To)       'GET THE PAY TO
            Pay_To = Trim(Strings.Left(Pay_To, 2))
            Wrapper.HLL_ReadScreen(Wrapper.getPos(16, 21), 1, Stat)         'GET THE STATUS
            Stat = Trim(Strings.Left(Stat, 1))
            Wrapper.HLL_ReadScreen(Wrapper.getPos(16, 27), 4, Remark)       'GET THE REMARK
            Remark = Trim(Strings.Left(Remark, 4))
            Wrapper.HLL_ReadScreen(Amount_Paid_Screen, 9, Amount_paid)          'GET THE AMOUNT PAID
            Amount_paid = Trim(Strings.Left(Amount_paid, 9))
            Wrapper.HLL_ReadScreen(Wrapper.getPos(2, 55), 25, Patient_Name)     'GET THE PATIENT NAME
            Patient_Name = Trim(Strings.Left(Patient_Name, 25))
        End If

        cmd = New OleDbCommand("Update [PASS$] Set [PROCESSING DATE]='" & Todays_Date & "',[CLAIM NUMBER]='" & Claim_No & "',[CURRENCY CONVERTED (Y/N)]='" & Currency_Conv & "', [PAY TO]='" & Pay_To & "',[AMOUNT PAID]='" & Amount_paid & "',[REMARK CODE]='" & Remark & "',[CLAIM STATUS]='" & Stat & "',[ERROR DESCRIPTION]='" & Replace(Err_Status, "'", "''") & "',[CLAIM PROCESSING STATUS (Y/N)]='" & Processing_Flag & "',[PATIENT NAME EB]='" & Replace(Patient_Name, "'", "''") & "' Where [SL_NO]='" & SL_NO & "'", Con)
        cmd.ExecuteNonQuery()
        cmd = Nothing

        Patient_Name = Nothing

    End Function

    '*********************************************************************************
    'Function Name  - Error_Case()
    'Parameters     - Error Message, Amount Paid Position
    'Description    - Enter the Amount claimed for a particular benefit
    'Return         - Nothing
    '*********************************************************************************

    Private Function Error_Case(Error_Msg As String, Amount_Pos As Integer, Policy_Num As String)

        Dim bnf As String
        Dim stat As String
        Dim remk As String
        Dim xmldoc As New XmlDocument
        Dim xmlnode As XmlNodeList
        Dim snd_bnf As Boolean = False

        xmldoc.Load(Application.StartupPath & "\Resources\New_Scenarios.xml")
        xmlnode = xmldoc.GetElementsByTagName("Error")

        For i = 0 To xmlnode.Count - 1
            If xmlnode(i).Attributes.ItemOf("Name").Value = Error_Msg Then
                For Each child As XmlNode In xmlnode(i).ChildNodes
                    If child.Attributes.ItemOf("Name").Value = Consult_Type Then
                        bnf = child.InnerText
                        stat = child.Attributes.ItemOf("Status").Value
                        remk = child.Attributes.ItemOf("Remark").Value
                        Second_Benefit(bnf, stat, remk)
                        snd_bnf = True
                        Unknown_Err = False
                        Exit For
                    End If
                Next
                If snd_bnf = True Then
                    Exit For
                End If
            End If
        Next

        If snd_bnf = False Then
            Select Case Error_Msg
                Case "PV-OUT / VARIABLE BENEFIT CLAIM EXISTS ON SAME DAY - F9 TO BYPASS"
                    Pvout_error(Amount_Pos)
                    Unknown_Err = False

                Case "PV-OUT / VARIABLE BENEFIT CLAIM EXISTS ON SAME DAY"
                    Pvout_error(Amount_Pos)
                    Unknown_Err = False

                Case "CLINICAL OVERALL NO. OF VISITS EXCEEDED, PRESS <F10> to BYPASS"
                    Clinical_Visits_error(Amount_Pos)
                    Unknown_Err = False

                Case "CLINICAL OVERALL NO. OF VISITS EXCEEDED"
                    Clinical_Visits_error(Amount_Pos)
                    Unknown_Err = False

                Case "MAX DAY COUNTS EXCEEDED, PRESS <F10> TO BYPASS"
                    Maxday_error(Amount_Pos, Policy_Num)
                    Unknown_Err = False

                Case "MAX DAY COUNTS EXCEEDED"
                    Maxday_error(Amount_Pos, Policy_Num)
                    Unknown_Err = False

                Case "STATUS MUST BE 'S' 'R' OR 'C'"
                    Status_src_error(Amount_Pos)
                    Unknown_Err = False

                Case "STATUS MUST BE 'R'"
                    Member_Inactive_error(Amount_Pos)
                    Unknown_Err = False

                Case "CLINICAL OVERALL BNF AMOUNT EXCEEDED, PRESS <F10> TO BYPASS"
                    Clinical_Overall_error(Amount_Pos)
                    Unknown_Err = False

                Case "CLINICAL OVERALL BNF AMOUNT EXCEEDED"
                    Clinical_Overall_error(Amount_Pos)
                    Unknown_Err = False

                Case "ACCOUNT NO. NOT EXISTS/NOT VALID"
                    Account_No_error(Amount_Pos)
                    Unknown_Err = False

                Case Else
                    Unknown_Err = True
            End Select
        End If

    End Function

    '*********************************************************************************
    'Function Name  - Pvout_error()
    'Parameters     - Position of Amount Paid
    'Description    - Process a claim with PV-OUT VARIABLE CLAIM ERROR MESSAGE
    'Return         - Nothing
    '*********************************************************************************

    Private Function Pvout_error(Amountpaid As Integer)

        Wrapper.HLL_CopyStringToPS("R", Wrapper.getPos(16, 21)) 'Update Status
        Wrapper.HLL_CopyStringToPS("    ", Wrapper.getPos(16, 27)) 'Update Remark
        Wrapper.HLL_CopyStringToPS("5", Wrapper.getPos(16, 27)) 'Update Remark
        Wrapper.HLL_CopyStringToPS("         ", Amountpaid) 'Delete Amount Paid

    End Function

    '*********************************************************************************
    'Function Name  - Clinical_Visits_error()
    'Parameters     - Position of Amount Paid
    'Description    - Process a claim with CLINICAL VISISTS ERROR MESSAGE 
    'Return         - Nothing
    '*********************************************************************************

    Private Function Clinical_Visits_error(Amountpaid As Integer)

        Wrapper.HLL_CopyStringToPS("R", Wrapper.getPos(16, 21)) 'Update Status
        Wrapper.HLL_CopyStringToPS("    ", Wrapper.getPos(16, 27)) 'Update Remark
        Wrapper.HLL_CopyStringToPS("6", Wrapper.getPos(16, 27)) 'Update Remark
        Wrapper.HLL_CopyStringToPS("         ", Amountpaid) 'Delete Amount Paid

    End Function

    '*********************************************************************************
    'Function Name  - Maxday_error()
    'Parameters     - Position of Amount Paid
    'Description    - Process a claim with MAX DAY COUNT ERROR MESSAGE 
    'Return         - Nothing
    '*********************************************************************************

    Private Function Maxday_error(Amountpaid As Integer, Policy_Num As String)

        If maxday_error_hand.Contains(Policy_Num) Then
            Wrapper.HLL_CopyStringToPS("C", Wrapper.getPos(16, 21)) 'Update Status
        ElseIf Consult_Type = "General Practitioner" Then

        Else
            Wrapper.HLL_CopyStringToPS("R", Wrapper.getPos(16, 21)) 'Update Status
            Wrapper.HLL_CopyStringToPS("    ", Wrapper.getPos(16, 27)) 'Update Remark
            Wrapper.HLL_CopyStringToPS("6P", Wrapper.getPos(16, 27)) 'Update Remark
            Wrapper.HLL_CopyStringToPS("         ", Amountpaid) 'Delete Amount Paid
        End If

    End Function

    '*********************************************************************************
    'Function Name  - Status_src_error()
    'Parameters     - Position of Amount Paid
    'Description    - Process a claim with STATUS MUST BE S,R OR C ERROR MESSAGE
    'Return         - Nothing
    '*********************************************************************************

    Private Function Second_Benefit(Bnfit As String, stat As String, remark5 As String)

        Dim index1 As Integer
        Dim Benefit_Pages1 As Integer
        Dim X_Pos1 As Integer
        Dim Y_Pos1 As Integer
        Dim status2 As String
        Dim bnf_amt As String
        Dim reim_per As String
        Dim A_Amt As String

        Wrapper.HLL_CopyStringToPS("         ", Amount_Claimed_Pos)        'Delete Amount Claimed
        Wrapper.HLL_CopyStringToPS("         ", Amountpaid_Pos)        'Delete Amount Claimed

        status2 = Nothing
        Do Until status2 = "BEGINNING OF FILE REACH"
            Wrapper.SendStr("@u") 'Page Down
            Wrapper.HLL_Pause(Session_ID, 2)
            status2 = Read_StatusBar()
            Wrapper.SendStr("#@")
            Wrapper.HLL_Wait()
            If status2 = "BEGINNING OF FILE REACH" Then
                Exit Do
            End If
        Loop

        If Benefit_Headers.Contains(Bnfit) Then
            index1 = Benefit_Headers.IndexOf(Bnfit)

            Benefit_Pages1 = Math.Ceiling((index1 + 1) / 5) - 1 'ROUNDUP THE VALUE TO GET THE NUMBER OF PAGE DOWNS

            For p = 1 To Benefit_Pages1
                Wrapper.SendStr("@v")
                Wrapper.HLL_Wait()
            Next

            X_Pos1 = 19
            Y_Pos1 = 19 + (11 * (index1 Mod 5)) 'GET THE POSITION OF A BENEFIT BASED ON THE ARRAY INDEX

            Wrapper.HLL_CopyStringToPS(Amount, Wrapper.getPos(X_Pos1, Y_Pos1)) 'Send the Amount to be claimed


            Wrapper.HLL_ReadScreen(Wrapper.getPos((9 + index1 Mod 5), 27), 7, bnf_amt)
            bnf_amt = Trim(Strings.Left(bnf_amt, 7))

            Wrapper.HLL_ReadScreen(Wrapper.getPos(9 + index1 Mod 5, 49), 6, reim_per)
            reim_per = Trim(Strings.Left(reim_per, 6))


            A_Amt = Amount * Convert.ToInt32(reim_per)

            If A_Amt < bnf_amt Then
                Wrapper.HLL_CopyStringToPS(A_Amt, Wrapper.getPos(X_Pos1 + 1, Y_Pos1))
            Else
                Wrapper.HLL_CopyStringToPS(bnf_amt, Wrapper.getPos(X_Pos1 + 1, Y_Pos1))
            End If

            Amountpaid_Pos = Wrapper.getPos(X_Pos1 + 1, Y_Pos1) 'Capture The Amount paid position

            If Not stat = Nothing Or Not stat = "" Then
                Wrapper.HLL_CopyStringToPS(stat, Wrapper.getPos(16, 21))
            End If

            If Not remark5 = Nothing Or Not remark5 = "" Then
                Wrapper.HLL_CopyStringToPS("    ", Wrapper.getPos(16, 27))
                Wrapper.HLL_CopyStringToPS(remark5, Wrapper.getPos(16, 27))
            End If

        Else
            Wrapper.HLL_CopyStringToPS("C", Wrapper.getPos(16, 21))
            Wrapper.HLL_CopyStringToPS(Amount, Wrapper.getPos(19, 19))
        End If



    End Function

    '*********************************************************************************
    'Function Name  - Status_src_error()
    'Parameters     - Position of Amount Paid
    'Description    - Process a claim with STATUS MUST BE S,R OR C ERROR MESSAGE
    'Return         - Nothing
    '*********************************************************************************

    Private Function Status_src_error(Amountpaid As Integer)

        Dim DOC As String
        Dim PTD As String
        Dim DOC_Date As DateTime
        Dim PTD_Date As DateTime
        Dim Date_Difference As Integer

        Wrapper.HLL_ReadScreen(Wrapper.getPos(4, 34), 10, PTD)
        PTD = Trim(Strings.Left(PTD, 10))
        Wrapper.HLL_ReadScreen(Wrapper.getPos(4, 50), 10, DOC)
        DOC = Trim(Strings.Left(DOC, 10))

        PTD_Date = DateTime.Parse(PTD)
        DOC_Date = DateTime.Parse(DOC)

        Date_Difference = DateDiff(DateInterval.Day, PTD_Date, DOC_Date)

        If Date_Difference = 0 Or Date_Difference > 0 Then
            Wrapper.HLL_CopyStringToPS("S", Wrapper.getPos(16, 21)) 'Update Status
            Wrapper.HLL_CopyStringToPS("         ", Amountpaid) 'Delete Amount Paid
            If No_Verify = True Then
                Wrapper.SendStr("@E")
                Wrapper.HLL_Wait()
            End If
        Else
            Wrapper.HLL_CopyStringToPS("C", Wrapper.getPos(16, 21)) 'Update Status
            Wrapper.HLL_CopyStringToPS("         ", Amountpaid) 'Delete Amount Paid
        End If

    End Function

    '*********************************************************************************
    'Function Name  - Memeber_Inactive_error()
    'Parameters     - Position of Amount Paid
    'Description    - Process a claim with STATUS MUST BE 'R' ERROR MESSAGE
    'Return         - Nothing
    '*********************************************************************************

    Private Function Member_Inactive_error(Amountpaid As Integer)

        Dim DOC As String
        Dim EFF As String
        Dim TERM As String
        Dim DOC_Date As DateTime
        Dim EFF_Date As DateTime
        Dim TERM_Date As DateTime
        Dim Date_Difference_EFF As Integer
        Dim Date_Difference_TERM As Integer

        Wrapper.HLL_ReadScreen(Wrapper.getPos(3, 34), 10, EFF)
        EFF = Trim(Strings.Left(EFF, 10))
        Wrapper.HLL_ReadScreen(Wrapper.getPos(4, 50), 10, DOC)
        DOC = Trim(Strings.Left(DOC, 10))
        Wrapper.HLL_ReadScreen(Wrapper.getPos(3, 50), 10, TERM)
        TERM = Trim(Strings.Left(TERM, 10))

        EFF_Date = DateTime.Parse(EFF)
        DOC_Date = DateTime.Parse(DOC)
        TERM_Date = DateTime.Parse(TERM)

        Date_Difference_EFF = DateDiff(DateInterval.Day, EFF_Date, DOC_Date)
        Date_Difference_TERM = DateDiff(DateInterval.Day, TERM_Date, DOC_Date)

        If Date_Difference_EFF < 0 Then
            Wrapper.HLL_CopyStringToPS("R", Wrapper.getPos(16, 21)) 'Update Status
            Wrapper.HLL_CopyStringToPS("    ", Wrapper.getPos(16, 27)) 'Update Remark
            Wrapper.HLL_CopyStringToPS("1", Wrapper.getPos(16, 27)) 'Update Remark
            Wrapper.HLL_CopyStringToPS("         ", Amountpaid) 'Delete Amount Paid
        ElseIf Date_Difference_TERM = 0 Or Date_Difference_TERM > 0 Then
            Wrapper.HLL_CopyStringToPS("R", Wrapper.getPos(16, 21)) 'Update Status
            Wrapper.HLL_CopyStringToPS("    ", Wrapper.getPos(16, 27)) 'Update Remark
            Wrapper.HLL_CopyStringToPS("2", Wrapper.getPos(16, 27)) 'Update Remark
            Wrapper.HLL_CopyStringToPS("         ", Amountpaid) 'Delete Amount Paid
        Else
            Wrapper.HLL_CopyStringToPS("C", Wrapper.getPos(16, 21)) 'Update Status
        End If

    End Function

    '*********************************************************************************
    'Function Name  - Clinical_Overall_error()
    'Parameters     - Position of Amount Paid
    'Description    - Process a claim with CLINICAL OVERALL BENEFIT ERROR MESSAGE
    'Return         - Nothing
    '*********************************************************************************

    Private Function Clinical_Overall_error(Amountpaid As Integer)

        Dim Amount As String
        Dim Overall_Limit As String
        Dim Overall_Amount As Double

        Dim A_Val As Double
        Dim B_Val As Double

        Wrapper.HLL_ReadScreen(Wrapper.getPos(14, 67), 13, Overall_Limit)       'Capture Overall Amount
        Overall_Limit = Trim(Strings.Left(Overall_Limit, 13))
        Overall_Amount = Convert.ToDouble(Overall_Limit)

        A_Val = Overall_Amount - Paid_Amount

        If A_Val = 0 Or A_Val < 0 Then

            Wrapper.HLL_CopyStringToPS("R", Wrapper.getPos(16, 21))             'Update Status
            Wrapper.HLL_CopyStringToPS("    ", Wrapper.getPos(16, 27))          'Update Remark
            Wrapper.HLL_CopyStringToPS("28", Wrapper.getPos(16, 27))            'Update Remark
            Wrapper.HLL_CopyStringToPS("         ", Amountpaid)                 'Delete Amount Paid

        ElseIf A_Val > 0 Then

            Wrapper.HLL_ReadScreen(Amountpaid, 9, Amount)
            Amount = Trim(Strings.Left(Amount, 9))

            B_Val = A_Val - Amount

            If B_Val < 0 Then
                Wrapper.HLL_CopyStringToPS("         ", Amountpaid)             'Delete Amount Paid
                Wrapper.HLL_CopyStringToPS(Convert.ToString(A_Val), Amountpaid) 'Delete Amount Paid
                Wrapper.HLL_CopyStringToPS("P", Wrapper.getPos(16, 21))         'Update Status
                Wrapper.HLL_CopyStringToPS("    ", Wrapper.getPos(16, 27))      'Update Remark
                Wrapper.HLL_CopyStringToPS("28", Wrapper.getPos(16, 27))        'Update Remark
            End If
        End If

    End Function

    '*********************************************************************************
    'Function Name  - Pvout_error()
    'Parameters     - Position of Amount Paid
    'Description    - Process a claim with PV-OUT VARIABLE CLAIM ERROR MESSAGE
    'Return         - Nothing
    '*********************************************************************************

    Private Function Account_No_error(Amountpaid As Integer)

        Dim Payto As String
        Dim Method As String
        Dim Remark As String
        Dim Status As String

        Status = Nothing

        Wrapper.HLL_ReadScreen(Wrapper.getPos(15, 55), 2, Payto)
        Wrapper.HLL_ReadScreen(Wrapper.getPos(15, 67), 1, Method)
        Wrapper.HLL_ReadScreen(Wrapper.getPos(3, 6), 20, Remark)

        Payto = Trim(Strings.Left(Payto, 2))
        Method = Trim(Strings.Left(Method, 1))
        Remark = Trim(Strings.Left(Remark, 20))

        If Payto = "EE" And Method = "A" Then

            Wrapper.HLL_CopyStringToPS("ER", Wrapper.getPos(15, 55))
            Wrapper.SendStr("@E")
            Wrapper.HLL_Pause(Session_ID, 3)
            Status = Read_StatusBar()
            Wrapper.SendStr("#@")
            Wrapper.HLL_Wait()

            If Status = "ACCOUNT NO. NOT EXISTS/NOT VALID" Then
                If Remark = "EE-C" And Not Remark = "ER-C" Then
                    Wrapper.HLL_CopyStringToPS("EE", Wrapper.getPos(15, 55))    'Update PayTo
                    Wrapper.HLL_CopyStringToPS("C", Wrapper.getPos(15, 67))     'Update Method
                    Wrapper.HLL_CopyStringToPS("C", Wrapper.getPos(16, 21))     'Update Status
                ElseIf Remark = "ER-C" Then
                    Wrapper.HLL_CopyStringToPS("ER", Wrapper.getPos(15, 55))    'Update PayTo
                    Wrapper.HLL_CopyStringToPS("C", Wrapper.getPos(15, 67))     'Update Method
                    Wrapper.HLL_CopyStringToPS("C", Wrapper.getPos(16, 21))     'Update Status
                Else
                    Wrapper.HLL_CopyStringToPS("EE", Wrapper.getPos(15, 55))    'Update PayTo
                    Wrapper.HLL_CopyStringToPS("C", Wrapper.getPos(15, 67))     'Update Method
                    Wrapper.HLL_CopyStringToPS("C", Wrapper.getPos(16, 21))     'Update Status
                End If
            End If

        ElseIf Payto = "ER" And Method = "A" Then
            Wrapper.HLL_CopyStringToPS("C", Wrapper.getPos(16, 21))     'Update Status
        ElseIf Payto = "PL" Or Payto = "DR" Then
            Wrapper.HLL_CopyStringToPS("C", Wrapper.getPos(16, 21))     'Update Status
        End If

    End Function

    '*********************************************************************************
    'Function Name  - Capture_Benefit()
    'Parameters     - Consultation Type, Amount to be claimed
    'Description    - Enter the Amount claimed for a particular benefit
    'Return         - Amount paid position
    '*********************************************************************************

    Private Function Capture_Benefit(Conslt_type As String, Amount As Double, PolicyNo As String)

        Dim XMLDoc1 As New XmlDocument
        Dim XMLNode1 As XmlNodeList
        Dim xmldoc2 As New XmlDocument
        Dim xmlnode2 As XmlNodeList
        Dim xmlnode3 As XmlNodeList

        Dim Doctor_Benefit As String
        Dim X_Cor As Integer
        Dim Pgdn As Integer
        Dim status As String
        Dim Benefit As String
        'Dim Benefit_Headers As New ArrayList
        Dim Priority As String
        Dim Benefit_Priority As String()
        Dim Benefit_List As New ArrayList
        Dim i As Integer
        Dim Benefit_per_Page As Integer = 5
        Dim Benefit_Pages As Integer

        Dim Remark_Code1 As String
        Dim Status_EB1 As String

        Dim Amount_Paid As String
        Dim O_Lmt As String

        Dim X_Pos As Integer
        Dim Y_Pos As Integer

        Dim Index As Integer
        Dim Benefit_Mod As Integer
        Dim claim_flag As Boolean = False


        Pgdn = 0
        X_Cor = 9

        status = Nothing
        Benefit_Headers.Clear()
        Benefit_List.Clear()

        Do Until status = "END OF FILE REACH"

            For k = 1 To Benefit_per_Page

                Wrapper.HLL_ReadScreen(Wrapper.getPos(X_Cor, 2), 6, Benefit) 'Read Benefit
                Wrapper.HLL_ReadScreen(Wrapper.getPos(X_Cor, 76), 5, O_Lmt) 'Read Benefit
                Wrapper.HLL_ReadScreen(Wrapper.getPos(X_Cor, 16), 10, Amount_Paid) 'Read Benefit

                Benefit = Trim(Strings.Left(Benefit, 6))
                O_Lmt = Trim(Strings.Left(O_Lmt, 5))
                Amount_Paid = Trim(Strings.Left(Amount_Paid, 10))

                If Amount_Paid = "" Or Amount_Paid = Nothing Then
                    Amount_Paid = "0"
                End If

                If Benefit = "" Or Benefit = Nothing Then
                    Benefit_Headers.Add("")
                Else
                    Benefit_Headers.Add(Benefit) 'Add Benefit to Array
                    If O_Lmt = "Y" Then
                        Paid_Amount = Paid_Amount + Convert.ToDouble(Amount_Paid)
                    End If
                End If

                X_Cor = X_Cor + 1
                Benefit = Nothing
                O_Lmt = Nothing
                Amount_Paid = Nothing
            Next

            Wrapper.SendStr("@v") 'Page Down
            Wrapper.HLL_Pause(Session_ID, 2)
            Pgdn = Pgdn + 1
            status = Read_StatusBar()
            Wrapper.SendStr("#@")
            Wrapper.HLL_Wait()
            X_Cor = 9

        Loop

        Wrapper.SendStr("#@")
        Wrapper.HLL_Wait()

        i = Nothing

        For i = 1 To Pgdn - 1
            Wrapper.SendStr("@u") 'Page Up
            Wrapper.HLL_Wait()
        Next

        XMLDoc1.Load(Application.StartupPath & "\Resources\Benefit_Header.xml")
        XMLNode1 = XMLDoc1.GetElementsByTagName("Benefit")

        For k = 0 To XMLNode1.Count - 1
            If XMLNode1(k).Attributes.ItemOf("Name").Value = Conslt_type Then
                Priority = XMLNode1(k).ChildNodes(0).InnerText
                Remark_Code1 = XMLNode1(k).Attributes.ItemOf("Remark").Value
                Status_EB1 = XMLNode1(k).Attributes.ItemOf("Status").Value
                Exit For
            End If
        Next

        Benefit_Priority = Strings.Split(Priority, ",")

        For Each ele In Benefit_Priority
            Benefit_List.Add(ele)
        Next

        xmldoc2.Load(Application.StartupPath & "\Resources\New_Scenarios.xml")
        xmlnode2 = xmldoc2.GetElementsByTagName("Code")

        For j = 0 To xmlnode2.Count - 1
            If xmlnode2(j).Attributes.ItemOf("ID").Value = Trim(Doctor_Code) Then
                For g = 0 To xmlnode2(j).ChildNodes.Count - 1
                    If xmlnode2(j).ChildNodes(g).Attributes.ItemOf("Name").Value = Conslt_type Then
                        Doctor_Benefit = xmlnode2(j).ChildNodes(g).InnerText
                        Exit For
                    End If
                Next
                Exit For
            End If
        Next

        xmlnode3 = xmldoc2.GetElementsByTagName("Benefit")

        'For i = 0 To xmlnode3.Count - 1
        '    If xmlnode3(i).Attributes.ItemOf("Policy").Value = PolicyNo And xmlnode3(i).Attributes.ItemOf("Consultation").Value = Conslt_type Then
        '        For Each child_node1 As XmlNode In xmlnode3(i).ChildNodes

        '        Next
        '        Benefit_List.Clear()
        '        Benefit_List.Insert(0, xmlnode3(i).InnerText)
        '        Well_Flag = True
        '        Exit For
        '    End If
        'Next
        For i = 0 To xmlnode3.Count - 1
            If xmlnode3(i).Attributes.ItemOf("Policy").Value = PolicyNo Then
                For Each child_node1 As XmlNode In xmlnode3(i).ChildNodes
                    If child_node1.Attributes.ItemOf("Name").Value = Consult_Type Then
                        Benefit_List.Clear()
                        Benefit_List.Insert(0, child_node1.InnerText)
                        Well_Flag = True
                        Exit For
                    End If
                Next
                If Well_Flag = True Then
                    Exit For
                End If
            End If
        Next

        'If Conslt_type = "Chinese Herbalist" Then
        '    If Benefit_Headers.Contains("B/H/AC") And Benefit_Headers.Contains("B/H/AT") Then
        '        Benefit_Flag = True
        '    End If
        'End If

        'If Not Benefit_Flag = True Then
        If Not Doctor_Benefit = Nothing Or Not Doctor_Benefit = "" Then
            Benefit_List.Insert(0, Doctor_Benefit)
        End If

        'If Special_Doctor.Contains(Doctor_Code) Then
        '    Benefit_Priority = Nothing
        '    ReDim Benefit_Priority(1)
        '    'Benefit_Priority(0) = "GOVOUT"
        '    Benefit_Priority(0) = SP_Doc_Benefit(Special_Doctor.IndexOf(Doctor_Code))
        'End If

        For Each beneft In Benefit_List
            If Benefit_Headers.Contains(beneft) Then

                claim_flag = True
                Index = Benefit_Headers.IndexOf(beneft)

                Benefit_Pages = Math.Ceiling((Index + 1) / Benefit_per_Page) - 1 'ROUNDUP THE VALUE TO GET THE NUMBER OF PAGE DOWNS

                For p = 1 To Benefit_Pages
                    Wrapper.SendStr("@v")
                    Wrapper.HLL_Wait()
                Next

                X_Pos = 19
                Y_Pos = 19 + (11 * (Index Mod 5)) 'GET THE POSITION OF A BENEFIT BASED ON THE ARRAY INDEX

                Wrapper.HLL_CopyStringToPS(Amount, Wrapper.getPos(X_Pos, Y_Pos)) 'Send the Amount to be claimed
                Amount_Claimed_Pos = Wrapper.getPos(X_Pos, Y_Pos)
                Capture_Benefit = Wrapper.getPos(X_Pos + 1, Y_Pos) 'Capture The Amount paid position

                Exit For
            End If
        Next
        'End If

        If claim_flag = False And Well_Flag = True Then
            Wrapper.HLL_CopyStringToPS(Amount, Wrapper.getPos(19, 19))
            Capture_Benefit = Wrapper.getPos(20, 19)
            No_Bene_Flag = True
        ElseIf claim_flag = False Then
            Wrapper.HLL_CopyStringToPS(Amount, Wrapper.getPos(19, 19))
            Capture_Benefit = Wrapper.getPos(20, 19)
            Wrapper.HLL_CopyStringToPS("    ", Wrapper.getPos(16, 27)) 'Update Remark
            Wrapper.HLL_CopyStringToPS(Remark_Code1, Wrapper.getPos(16, 27))
            Wrapper.HLL_CopyStringToPS(Status_EB1, Wrapper.getPos(16, 21))
            No_Bene_Flag = True
        End If

    End Function

    '*********************************************************************************
    'Function Name  - Sign_On()
    'Parameters     - Excel file
    'Description    - Extract user name and password from the Excel file
    'Return         - Nothing
    '*********************************************************************************

    Private Function Sign_On()

        Dim sign_str As String
        Dim Library_str As String
        Dim Username As String
        Dim Password As String
        Dim p As Process()
        Dim rls_counter As Integer = 0

        p = Process.GetProcessesByName("pcsws")

        If p.Count = 0 Then
            Dim MyProcess As Process
            MyProcess = Process.Start(My.Computer.FileSystem.SpecialDirectories.Desktop & "\HKAS02.ws")

            MyProcess.WaitForExit(5000)

            Window_Title = MyProcess.MainWindowTitle
        Else
            Window_Title = p(0).MainWindowTitle
        End If

        'CONNECT TO THE PRESENTATION SPACE
        Wrapper.HLL_QuerySession()
        Session_ID = Trim(Strings.Left(Wrapper.mstr_QueryData, 1))
        Wrapper.HLL_ConnectPS(Session_ID)


        Dim xlapp As New Excel.Application
        Dim xlwb As Excel.Workbook = xlapp.Workbooks.Open(My.Computer.FileSystem.SpecialDirectories.MyDocuments & "\Username and Password - HCP and EB.xlsx", Password:="HCPEB") 'Excel workbook to store the PDF table
        Dim xlsheet As Excel.Worksheet
        Dim rang As Excel.Range

        xlsheet = xlwb.Worksheets("Sheet1")

        Username = xlsheet.Range("A2").Value
        Password = xlsheet.Range("B2").Value

        xlwb.Save()
        xlwb.Close()
        xlapp.Quit()
        xlwb = Nothing
        xlapp = Nothing


        If p.Count = 0 Then
            AutoIt.AutoItX.AutoItSetOption("WinTitleMatchMode", 2)
            AutoIt.AutoItX.ControlSetText("IBM i signon", "", "Edit2", Username)
            AutoIt.AutoItX.ControlSetText("IBM i signon", "", "Edit3", Password)
            AutoIt.AutoItX.ControlSend("IBM i signon", "", "Button1", "{ENTER}")
        End If
        'Read the Sign On Screen and Enter the login credentials
        Do
            Thread.Sleep(300)
            sign_str = Nothing
            Wrapper.HLL_ReadScreen(Wrapper.getPos(1, 36), 7, sign_str)
            sign_str = Trim(Strings.Left(sign_str, 7))
            rls_counter = rls_counter + 1

            If sign_str = "Sign On" Then
                Exit Do
            ElseIf rls_counter = 30 Then
                MetroMessageBox.Show(Form1, "Tool could not sign-on to EB system" & vbCrLf & "Please try again later", "EB Sign-On Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Application.Exit()
                End
            End If
        Loop Until (sign_str = "Sign On")

        Wrapper.HLL_CopyStringToPS(Username, Wrapper.getPos(6, 53))
        Wrapper.HLL_CopyStringToPS(Password, Wrapper.getPos(7, 53))
        Wrapper.SendStr("@E")
        Wrapper.HLL_Wait()

        Library_str = Nothing

        'Traverse towards library screen
        Do
            Library_str = Nothing
            Wrapper.HLL_ReadScreen(Wrapper.getPos(2, 2), 7, Library_str)
            Library_str = Trim(Strings.Left(Library_str, 7))
            If Library_str = "SUSEL01" Then
                Exit Do
            Else
                Wrapper.SendStr("@E")
                Wrapper.HLL_Wait()
            End If
        Loop Until (Library_str = "SUSEL01​")

        Wrapper.HLL_CopyStringToPS("X", Wrapper.getPos(12, 6))
        Wrapper.SendStr("@E")
        Wrapper.HLL_Wait()

    End Function

    '*********************************************************************************
    'Function Name  - Screen_Flow()
    'Parameters     - XML File
    'Description    - Extract the flow from the XML Config for the required screen
    'Return         - Nothing
    '*********************************************************************************

    Private Function Screen_Flow(Screen_Name As String, Tag As String)

        Dim XMLDoc As New XmlDocument
        Dim XMLNode As XmlNodeList
        Dim Flow As String = Nothing
        Dim Scrn_Flow As String()
        Dim Options As String()
        Dim Current_Date As String

        XMLDoc.Load(Application.StartupPath & "\Resources\EB_Config.xml")
        XMLNode = XMLDoc.GetElementsByTagName("Screen")

        For i = 0 To XMLNode.Count - 1
            If XMLNode(i).Attributes.ItemOf("Name").Value = Screen_Name Then
                For Each Field As XmlNode In XMLNode(i).ChildNodes
                    Select Case Field.Name
                        Case Tag
                            Flow = Field.InnerText
                    End Select
                Next
            End If
        Next

        Scrn_Flow = Strings.Split(Flow, ",")

        For Each flow_scrn As String In Scrn_Flow
            If Tag = "Flow" Then
                Options = Strings.Split(flow_scrn, " ")
                For Each opt As String In Options
                    Wrapper.SendStr(opt)
                    Wrapper.HLL_Wait()
                Next
            Else
                Wrapper.SendStr(flow_scrn)
                Wrapper.HLL_Wait()
            End If
        Next

    End Function

    '**********************************************************************************
    'Function Name  - Read_Ex_Rate()
    'Parameters     - XML Config
    'Description    - Extract the flow from Currency Exchnage rate screen
    'Return         - Nothing
    '**********************************************************************************

    Private Function Read_Ex_Rate()

        Dim Today_Date As Date
        Dim Now_Date As Date
        Dim Current_Date As String
        Dim Exchange_Rate As String
        Dim Error_Msg As String
        Dim cnt As Integer
        Dim i As Integer
        Dim prog_up As Integer

        Dim xlapp As New Excel.Application
        Dim xlwb As Excel.Workbook = xlapp.Workbooks.Open(Config, Password:="HCPEB") 'Excel workbook to store the PDF table
        Dim xlsheet As Excel.Worksheet
        Dim rang As Excel.Range

        Dim myarray As ArrayList = New ArrayList

        xlsheet = xlwb.Worksheets("CCY")

        Today_Date = xlsheet.Range("D2").Value
        Today_Date = Today_Date.Date
        Now_Date = Date.Now.Date

        If Not Today_Date = Now_Date Then

            xlsheet.Range("D2").Value = Now_Date

            Screen_Flow("FMRATH", "Flow")

            For Each rang In xlsheet.Range("A2:A" & xlsheet.UsedRange.Rows.Count)
                myarray.Add(rang.Value)
            Next

            cnt = 1
            i = 2
            prog_up = 1

            Form1.MetroProgressBar1.Maximum = xlsheet.UsedRange.Rows.Count - 1
            Form1.Update()

            For Each item In myarray

                If Not item = "" Or Not item = Nothing Then
                    Form1.MetroLabel1.Text = Nothing
                    Form1.Update()
                    Form1.MetroLabel1.Text = "Capturing Exchange Rate"
                    Form1.Update()
                    Form1.MetroProgressBar1.Value = prog_up
                    Form1.MetroProgressBar1.Update()
                    Form1.MetroLabel1.Text = Nothing
                    Form1.Update()
                    Form1.MetroLabel1.Text = "Currency : " & item
                    Form1.MetroLabel1.Update()

                    Current_Date = Date.Now.ToString("yyyyMMdd")
                    Wrapper.HLL_CopyStringToPS(item, Wrapper.getPos(5, 8))
                    Wrapper.HLL_Wait()

                    Do
                        Wrapper.HLL_CopyStringToPS(Current_Date, Wrapper.getPos(5, 22))
                        Wrapper.HLL_Wait()
                        Wrapper.SendStr("@E")
                        Wrapper.HLL_Wait()
                        Wrapper.HLL_ReadScreen(Wrapper.getPos(24, 2), 53, Error_Msg)
                        'Decrease one day on error
                        Current_Date = Now_Date.AddDays("-" & cnt).ToString("yyyyMMdd")
                        cnt = cnt + 1
                    Loop Until (Trim(Error_Msg) = "" Or Trim(Error_Msg) = Nothing)

                    Wrapper.HLL_ReadScreen(Wrapper.getPos(5, 38), 12, Exchange_Rate)
                    Exchange_Rate = Trim(Strings.Left(Exchange_Rate, 9))

                    xlsheet.Range("B" & i).Value = Exchange_Rate
                    i = i + 1
                    cnt = 1
                    prog_up = prog_up + 1
                    Wrapper.SendStr("@E")
                    Wrapper.HLL_Wait()

                    Current_Date = Nothing
                    Exchange_Rate = Nothing
                End If
            Next

            Screen_Flow("FMRATH", "Back_Home")

        End If

        xlwb.Save()
        xlwb.Close()
        xlapp.Quit()
        xlwb = Nothing
        xlapp = Nothing

    End Function

    '**********************************************************************************
    'Function Name  - Read_StatusBar() - Autoit Function
    'Parameters     - Autoit and Window Title
    'Description    - Extract the status from the Window title using the window handle
    'Return         - Status Bar Contents
    '**********************************************************************************

    Private Function Read_StatusBar()

        Dim status1 As String

        AutoIt.AutoItX.AutoItSetOption("WinTitleMatchMode", 2)
        'Get the status bar text
        status1 = AutoIt.AutoItX.StatusBarGetText(Window_Title)
        status1 = Trim(status1)

        Read_StatusBar = status1

    End Function

    Private Function Shared_drive()

        Dim xmldoc As New XmlDocument
        Dim xmlnode As XmlNodeList
        Dim File_Path As String

        File_Path = Directory.GetCurrentDirectory()

        xmldoc.Load(File_Path & "\Path_Config.xml")
        xmlnode = xmldoc.GetElementsByTagName("SharedLocation")

        Shared_Path = xmlnode(0).Attributes.ItemOf("Path").Value

    End Function

End Class
