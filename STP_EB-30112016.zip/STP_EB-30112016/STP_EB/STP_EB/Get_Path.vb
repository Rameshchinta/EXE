﻿Imports System.Xml
Imports System.IO

Public Class Get_Path

    Public xmlnode As XmlNodeList
    Public xmldoc As New XmlDocument
    Public Shared_Drive As String
    Public File_Path As String

    Public Sub GetPath()

        Shared_path()

    End Sub

    Public Function Shared_path()

        File_Path = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().CodeBase)

        xmldoc.Load(File_Path & "\Path_Config.xml")
        xmlnode = xmldoc.GetElementsByTagName("SharedLocation")

        Shared_Drive = xmlnode(0).Attributes.ItemOf("Path").Value

    End Function

End Class
