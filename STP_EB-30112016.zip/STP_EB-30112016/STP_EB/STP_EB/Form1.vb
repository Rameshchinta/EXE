﻿Imports MetroFramework
Imports System.IO

Public Class Form1

    Private Sub MetroButton1_Click(sender As Object, e As EventArgs) Handles MetroButton1.Click

        MetroLabel1.Text = "Execution In-Progress"
        Me.Update()

        If Not File.Exists(Directory.GetCurrentDirectory & "\Path_Config.xml") Then
            My.Computer.FileSystem.WriteAllText(Directory.GetCurrentDirectory & "\Path_Config.xml", My.Resources.Path_Config, True)
        End If

        Dim Fold_Structure As New Folder_Struct
        Fold_Structure.Check_Folder_Structure()

        MetroMessageBox.Show(Me, "Successfully Completed", "Completion Status", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Application.Exit()
        End

    End Sub

End Class