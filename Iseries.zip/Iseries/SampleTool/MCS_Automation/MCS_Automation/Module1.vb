﻿Imports System.Data.OleDb

Module Module1

    Sub Main()
        IBMISeries.Wrapper.HLL_ConnectPS("A")
        MainScreenToPEScreen()
    End Sub

    Sub MainScreenToPEScreen()
        Dim fileName As String = IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "Navigation_File.xls")
        'oleedb connection for tool tip
        Dim ole As New OleDb.OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source= " + fileName + ";extended properties='Excel 12.0 Xml';")
        ole.Open()
        Dim strSQL As String = "select COUNT(*) from[Sheet1$]" 'Query to get the number of ACT filenames entered'

        Dim CMD As New OleDbCommand(strSQL, ole)
        Dim DR As OleDbDataReader
        DR = CMD.ExecuteReader() 'Populate the reader'
        DR.Read()

        Dim totalEntries = DR(0).ToString()

        Dim key As String
        Dim selectKeys As New OleDbDataAdapter("select [Keys] from[Sheet1$]", ole)
        Dim datS As New DataSet
        selectKeys.Fill(datS)

        For i = 0 To totalEntries - 1
            key = datS.Tables(0).Rows(i).ItemArray(0)
            If key.Equals("Read") Then
                Dim pNo As String = Nothing
                'sets cursor to the position of S. AG(9,7)
                IBMISeries.Wrapper.HLL_SetCursor(IBMISeries.Wrapper.getPos(9, 7))
                'Copies value of policy no from the screen
                'HLL_ReadScreen(getPos(x-Cordinate,y-Cordinate),FieldLength,Variable)
                IBMISeries.Wrapper.HLL_ReadScreen(IBMISeries.Wrapper.getPos(2, 9), 11, pNo)
                MsgBox(pNo)
            Else
                IBMISeries.Wrapper.SendStr(key)
                IBMISeries.Wrapper.HLL_Wait()
            End If
        Next
        ole.Close()
    End Sub

End Module
